<?php

class GameManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    

private function getOrCreateAIUser() {
    // Check if AI user already exists
    $stmt = $this->pdo->prepare("SELECT id FROM users WHERE username = 'AI_PLAYER'");
    $stmt->execute();
    $aiUser = $stmt->fetch();
    
    if ($aiUser) {
        return $aiUser['id']; // Return existing AI user ID
    }
    
    // Create AI user if it doesn't exist
    $stmt = $this->pdo->prepare("
        INSERT INTO users (username, password_hash, email, wins, losses, created_at) 
        VALUES ('AI_PLAYER', 'no_password', 'ai@system.local', 0, 0, NOW())
    ");
    $stmt->execute();
    
    return $this->pdo->lastInsertId(); // Return new AI user ID
}



    public function createGame($creatorId, $gameName, $playerCount, $boardSize = 8, $gameMode = 'multiplayer', $aiDifficulty = 'medium') {
        global $send_game_notifications;
        
        $gameId = uniqid();
        
        $game = new HexChess($gameId, $playerCount, $boardSize);
        $gameState = serialize($game);
        
        $stmt = $this->pdo->prepare("
            INSERT INTO games (game_id, creator_id, game_name, player_count, board_size, game_state, game_mode, ai_difficulty) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$gameId, $creatorId, $gameName, $playerCount, $boardSize, $gameState, $gameMode, $aiDifficulty]);
        
        // Join the human player
        $this->joinGame($gameId, $creatorId);
        
        // For AI games, add AI player and start immediately
        if ($gameMode === 'ai') {
    error_log("DEBUG: Entering AI game setup for gameId: $gameId"); // <-- ADD THIS LINE
    
            // Add AI player (slot 1)
            $stmt = $this->pdo->prepare("INSERT INTO game_players (game_id, user_id, player_slot) VALUES (?, ?, ?)");
            //$stmt->execute([$gameId, -1, 1]); // -1 indicates AI player
            $aiUserId = $this->getOrCreateAIUser();
$stmt->execute([$gameId, $aiUserId, 1]); // Use real AI user ID

    error_log("DEBUG: AI player inserted, now starting game"); // <-- ADD THIS LINE
            // Start the game immediately
            $this->startGame($gameId);
    error_log("DEBUG: AI game setup completed successfully"); // <-- ADD THIS LINE
        }
        
        logActivity('game_created', "Game created: $gameName (ID: $gameId, Mode: $gameMode)", $creatorId);
        
        if ($send_game_notifications) {
            $stmt = $this->pdo->prepare("SELECT username FROM users WHERE id = ?");
            $stmt->execute([$creatorId]);
            $creator = $stmt->fetch();
            
            $modeText = $gameMode === 'ai' ? " vs AI ($aiDifficulty)" : '';
            
            $notificationMessage = "
                <h3>🎮 New Game Created!</h3>
                <p><strong>Game Name:</strong> " . htmlspecialchars($gameName) . "</p>
                <p><strong>Created by:</strong> " . htmlspecialchars($creator['username']) . "</p>
                <p><strong>Mode:</strong> " . ucfirst($gameMode) . "$modeText</p>
                <p><strong>Players:</strong> $playerCount</p>
                <p><strong>Board Size:</strong> $boardSize</p>
                <p><strong>Game ID:</strong> $gameId</p>
                <p><strong>Created:</strong> " . date('Y-m-d H:i:s') . "</p>
                <hr>
                <p>Total active games: " . $this->getActiveGameCount() . "</p>
            ";
            
            sendAdminNotification("New Game Created: $gameName", $notificationMessage);
        }
        
        return $gameId;
    }

    private function getActiveGameCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM games WHERE status IN ('waiting', 'active')");
        return $stmt->fetchColumn();
    }
    
    public function joinGame($gameId, $userId) {
        $stmt = $this->pdo->prepare("SELECT player_count FROM games WHERE game_id = ? AND status = 'waiting'");
        $stmt->execute([$gameId]);
        $game = $stmt->fetch();
        
        if (!$game) return false;
        
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM game_players WHERE game_id = ?");
        $stmt->execute([$gameId]);
        $playerCount = $stmt->fetch()['count'];
        
        if ($playerCount >= $game['player_count']) return false;
        
        $stmt = $this->pdo->prepare("INSERT INTO game_players (game_id, user_id, player_slot) VALUES (?, ?, ?)");
        $stmt->execute([$gameId, $userId, $playerCount]);
        
        if ($playerCount + 1 >= $game['player_count']) {
            $this->startGame($gameId);
        }
        
        return true;
    }
    
    private function startGame($gameId) {
        global $send_game_notifications;
        
        $stmt = $this->pdo->prepare("UPDATE games SET status = 'active', started_at = NOW() WHERE game_id = ?");
        $stmt->execute([$gameId]);
        
        $stmt = $this->pdo->prepare("
            SELECT g.game_name, g.player_count, u.username as creator
            FROM games g 
            JOIN users u ON g.creator_id = u.id 
            WHERE g.game_id = ?
        ");
        $stmt->execute([$gameId]);
        $gameInfo = $stmt->fetch();
        
        logActivity('game_started', "Game started: {$gameInfo['game_name']} (ID: $gameId)");
        
        if ($send_game_notifications) {
            $notificationMessage = "
                <h3>🚀 Game Started!</h3>
                <p><strong>Game:</strong> " . htmlspecialchars($gameInfo['game_name']) . "</p>
                <p><strong>Creator:</strong> " . htmlspecialchars($gameInfo['creator']) . "</p>
                <p><strong>Players:</strong> {$gameInfo['player_count']}</p>
                <p><strong>Game ID:</strong> $gameId</p>
                <p><strong>Started:</strong> " . date('Y-m-d H:i:s') . "</p>
            ";
            
            sendAdminNotification("Game Started: {$gameInfo['game_name']}", $notificationMessage);
        }
    }
    
    public function finishGame($gameId, $winnerId = null, $reason = 'completed') {
        global $send_game_notifications;
        
        $stmt = $this->pdo->prepare("
            UPDATE games SET status = 'finished', finished_at = NOW(), winner_id = ? 
            WHERE game_id = ?
        ");
        $stmt->execute([$winnerId, $gameId]);
        
        $stmt = $this->pdo->prepare("
            SELECT g.game_name, g.player_count, creator.username as creator_name,
                   winner.username as winner_name
            FROM games g 
            JOIN users creator ON g.creator_id = creator.id 
            LEFT JOIN users winner ON g.winner_id = winner.id
            WHERE g.game_id = ?
        ");
        $stmt->execute([$gameId]);
        $gameInfo = $stmt->fetch();
        
        $winnerText = $gameInfo['winner_name'] ? "Winner: {$gameInfo['winner_name']}" : "No winner";
        $reasonText = $reason === 'resignation' ? "(by resignation)" : "";
        logActivity('game_finished', "Game finished: {$gameInfo['game_name']} (ID: $gameId) - $winnerText $reasonText", $winnerId);
        
        if ($send_game_notifications) {
            $winnerDisplay = $gameInfo['winner_name'] ? htmlspecialchars($gameInfo['winner_name']) : 'No winner (draw/abandoned)';
            $reasonDisplay = $reason === 'resignation' ? ' (by resignation)' : '';
            
            $notificationMessage = "
                <h3>🏁 Game Completed!</h3>
                <p><strong>Game:</strong> " . htmlspecialchars($gameInfo['game_name']) . "</p>
                <p><strong>Creator:</strong> " . htmlspecialchars($gameInfo['creator_name']) . "</p>
                <p><strong>Winner:</strong> $winnerDisplay$reasonDisplay</p>
                <p><strong>Players:</strong> {$gameInfo['player_count']}</p>
                <p><strong>Game ID:</strong> $gameId</p>
                <p><strong>Finished:</strong> " . date('Y-m-d H:i:s') . "</p>
                <hr>
                <p>Games completed today: " . $this->getGamesCompletedToday() . "</p>
            ";
            
            sendAdminNotification("Game Completed: {$gameInfo['game_name']}", $notificationMessage);
        }
    }
    
    private function getGamesCompletedToday() {
        $stmt = $this->pdo->query("
            SELECT COUNT(*) FROM games 
            WHERE status = 'finished' AND DATE(finished_at) = CURDATE()
        ");
        return $stmt->fetchColumn();
    }
    
    public function getAvailableGames() {
        $stmt = $this->pdo->prepare("
            SELECT g.game_id, g.game_name, g.player_count, g.board_size, g.created_at,
                   u.username as creator, COUNT(gp.user_id) as current_players
            FROM games g
            JOIN users u ON g.creator_id = u.id
            LEFT JOIN game_players gp ON g.game_id = gp.game_id
            WHERE g.status = 'waiting'
            GROUP BY g.game_id
            ORDER BY g.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getGame($gameId) {
        $stmt = $this->pdo->prepare("SELECT * FROM games WHERE game_id = ?");
        $stmt->execute([$gameId]);
        $gameData = $stmt->fetch();
        
        if (!$gameData) return null;
        
        $game = unserialize($gameData['game_state']);
        
        $stmt = $this->pdo->prepare("
            SELECT gp.player_slot, gp.user_id, u.username 
            FROM game_players gp 
            JOIN users u ON gp.user_id = u.id 
            WHERE gp.game_id = ? 
            ORDER BY gp.player_slot
        ");
        $stmt->execute([$gameId]);
        $players = $stmt->fetchAll();
        
        $playerUsers = array_fill(0, $game->getPlayerCount(), null);
        foreach ($players as $player) {
            $playerUsers[$player['player_slot']] = $player['user_id'];
        }
        
        $game->setPlayerUsers($playerUsers);
        
        return ['game' => $game, 'data' => $gameData, 'players' => $players];
    }
    
    // NEW: Update game state method (replaces saveGame for better naming)
    public function updateGameState($gameId, $game) {
        $gameState = serialize($game);
        $stmt = $this->pdo->prepare("UPDATE games SET game_state = ?, updated_at = NOW() WHERE game_id = ?");
        
        try {
            $stmt->execute([$gameState, $gameId]);
            error_log("Game state updated for game $gameId");
            return true;
        } catch (PDOException $e) {
            error_log("Failed to update game state for game $gameId: " . $e->getMessage());
            return false;
        }
    }
    
    // Legacy method for backward compatibility
    public function saveGame($gameId, $game) {
        return $this->updateGameState($gameId, $game);
    }
    
    // NEW: Process resignation and update game accordingly
    public function processResignation($gameId, $resigningUserId) {
        $gameInfo = $this->getGame($gameId);
        if (!$gameInfo) {
            return ['success' => false, 'error' => 'Game not found'];
        }
        
        $game = $gameInfo['game'];
        $gameData = $gameInfo['data'];
        
        // Check if game is active
        if ($gameData['status'] !== 'active') {
            return ['success' => false, 'error' => 'Game is not active'];
        }
        
        // Find the player's slot
        $userPlayerSlot = null;
        foreach ($gameInfo['players'] as $player) {
            if ($player['user_id'] == $resigningUserId) {
                $userPlayerSlot = $player['player_slot'];
                break;
            }
        }
        
        if ($userPlayerSlot === null) {
            return ['success' => false, 'error' => 'You are not in this game'];
        }
        
        // Process resignation
        $result = $game->resignPlayer($userPlayerSlot);
        
        if ($result === true) {
            // Save the updated game state
            $this->updateGameState($gameId, $game);
            
            // Check if game is over and finish it
            $gameState = $game->getGameState();
            if ($gameState['gameStatus']['gameOver']) {
                $winnerId = $gameState['gameStatus']['winner'];
                $this->finishGame($gameId, $winnerId, 'resignation');
                
                // Update player stats
                $userObj = new User($this->pdo);
                
                // Update resigning player as loss
                $userObj->updateStats($resigningUserId, false);
                
                // Update winner if there is one
                if ($winnerId) {
                    $userObj->updateStats($winnerId, true);
                }
                
                // For 3-player games, other players don't get win/loss if game ends by resignation
                // This could be customized based on your game rules
            }
            
            return ['success' => true, 'message' => 'Resignation processed successfully'];
        } else {
            return ['success' => false, 'error' => $result ?: 'Failed to process resignation'];
        }
    }
    
    public function getUserGames($userId) {
        $stmt = $this->pdo->prepare("
            SELECT g.game_id, g.game_name, g.status, g.created_at, g.started_at, g.finished_at,
                   u.username as creator, winner.username as winner_name
            FROM games g
            JOIN game_players gp ON g.game_id = gp.game_id
            JOIN users u ON g.creator_id = u.id
            LEFT JOIN users winner ON g.winner_id = winner.id
            WHERE gp.user_id = ?
            ORDER BY g.created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }
    
    // NEW: Get user's active games for lobby display (allows multiple player slots for development)
    public function getUserActiveGames($userId) {
        $stmt = $this->pdo->prepare("
            SELECT g.game_id, g.game_name, g.status, g.created_at, g.started_at, g.finished_at,
                   g.player_count, g.board_size,
                   creator.username as creator, 
                   winner.username as winner_name,
                   gp_user.player_slot as user_player_slot,
                   (SELECT COUNT(*) FROM game_players WHERE game_id = g.game_id) as current_players
            FROM games g
            JOIN game_players gp_user ON g.game_id = gp_user.game_id AND gp_user.user_id = ?
            JOIN users creator ON g.creator_id = creator.id
            LEFT JOIN users winner ON g.winner_id = winner.id
            WHERE g.status IN ('waiting', 'active', 'finished')
            ORDER BY 
                CASE g.status 
                    WHEN 'active' THEN 1 
                    WHEN 'waiting' THEN 2 
                    WHEN 'finished' THEN 3 
                END,
                g.created_at DESC
            LIMIT 20
        ");
        $stmt->execute([$userId]);
        $games = $stmt->fetchAll(PDO::FETCH_ASSOC); // Clean JSON format
        
        // For each active game, check if it's the user's turn from this player slot perspective
        foreach ($games as &$game) {
            $game['is_your_turn'] = false;
            
            if ($game['status'] === 'active') {
                try {
                    $gameInfo = $this->getGame($game['game_id']);
                    if ($gameInfo) {
                        $gameObj = $gameInfo['game'];
                        // Check if it's this specific player slot's turn
                        $game['is_your_turn'] = ($gameObj->getCurrentPlayerSlot() == $game['user_player_slot']);
                    }
                } catch (Exception $e) {
                    error_log("Error checking turn for game {$game['game_id']}: " . $e->getMessage());
                    $game['is_your_turn'] = false;
                }
            }
        }
        
        return $games;
    }
    
    // NEW: Get game statistics for a user
    public function getUserGameStats($userId) {
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(*) as total_games,
                SUM(CASE WHEN g.status = 'finished' AND g.winner_id = ? THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN g.status = 'finished' AND g.winner_id != ? AND g.winner_id IS NOT NULL THEN 1 ELSE 0 END) as losses,
                SUM(CASE WHEN g.status = 'active' THEN 1 ELSE 0 END) as active_games,
                SUM(CASE WHEN g.status = 'waiting' THEN 1 ELSE 0 END) as waiting_games
            FROM games g
            JOIN game_players gp ON g.game_id = gp.game_id
            WHERE gp.user_id = ?
        ");
        $stmt->execute([$userId, $userId, $userId]);
        return $stmt->fetch();
    }
    
    // NEW: Check for abandoned games and clean them up
    public function cleanupAbandonedGames($hoursOld = 24) {
        // Mark games as finished if they've been active too long without moves
        $stmt = $this->pdo->prepare("
            UPDATE games 
            SET status = 'finished', finished_at = NOW() 
            WHERE status = 'active' 
            AND (updated_at IS NULL OR updated_at < DATE_SUB(NOW(), INTERVAL ? HOUR))
            AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
        ");
        $stmt->execute([$hoursOld, $hoursOld]);
        
        $abandonedCount = $stmt->rowCount();
        
        // Remove waiting games that are very old
        $stmt = $this->pdo->prepare("
            DELETE FROM games 
            WHERE status = 'waiting' 
            AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
        ");
        $stmt->execute([$hoursOld * 2]); // Wait longer for waiting games
        
        $removedCount = $stmt->rowCount();
        
        if ($abandonedCount > 0 || $removedCount > 0) {
            logActivity('cleanup', "Cleaned up $abandonedCount abandoned games and removed $removedCount old waiting games");
        }
        
        return ['abandoned' => $abandonedCount, 'removed' => $removedCount];
    }
}