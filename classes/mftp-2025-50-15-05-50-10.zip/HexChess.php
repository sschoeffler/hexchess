<?php

class HexChess {
    private $board;
    private $currentPlayer;
    private $gameId;
    private $players;
    private $playerCount;
    private $moveCount;
    private $boardSize;
    private $activePlayers;
    private $playerUsers; // Maps player slots to user IDs
    
    public function __construct($gameId = null, $playerCount = 2, $boardSize = 8) {
        $this->gameId = $gameId ?: uniqid();
        $this->playerCount = max(2, min(3, $playerCount));
        $this->currentPlayer = 0;
        $this->moveCount = 0;
        $this->boardSize = max(4, min(8, $boardSize));
        $this->playerUsers = array_fill(0, $this->playerCount, null);
        
        if ($this->playerCount == 2) {
            $this->players = ['red', 'blue'];
        } else {
            $this->players = ['red', 'blue', 'green'];
        }
        
        $this->activePlayers = array_fill(0, $this->playerCount, true);
        $this->initBoard();
    }
    
    public function setPlayerUsers($playerUsers) {
        $this->playerUsers = $playerUsers;
    }
    
    public function getPlayerUsers() {
        return $this->playerUsers;
    }
    
    public function canUserMove($userId) {
        return $this->playerUsers[$this->currentPlayer] == $userId;
    }
    
    // NEW: Resign functionality
    public function resignPlayer($playerSlot) {
        // Validate player slot
        if ($playerSlot < 0 || $playerSlot >= $this->playerCount) {
            return "Invalid player slot";
        }
        
        // Check if player is already inactive
        if (!$this->activePlayers[$playerSlot]) {
            return "Player already inactive";
        }
        
        // Mark player as inactive
        $this->activePlayers[$playerSlot] = false;
        
        // If it was the current player's turn, advance to next active player
        if ($this->currentPlayer === $playerSlot) {
            $this->advanceToNextActivePlayer();
        }
        
        // Log the resignation
        error_log("Player $playerSlot ({$this->players[$playerSlot]}) has resigned from game {$this->gameId}");
        
        return true;
    }
    
    // NEW: Get number of active players
    public function getActivePlayerCount() {
        return array_sum($this->activePlayers);
    }
    
    // NEW: Check if a specific player is active
    public function isPlayerActive($playerSlot) {
        return isset($this->activePlayers[$playerSlot]) ? $this->activePlayers[$playerSlot] : false;
    }
    
    // NEW: Get list of active players
    public function getActivePlayers() {
        return $this->activePlayers;
    }
    
    private function initBoard() {
        $this->board = [];
        
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                $this->board[$q][$r] = null;
            }
        }
        
        $this->setupPieces();
    }
    
    private function setupPieces() {
        if ($this->playerCount == 2) {
            $this->setupTwoPlayerPieces();
        } else {
            $this->setupThreePlayerPieces();
        }
    }
    
    private function setupTwoPlayerPieces() {
        // Player 1 (Red) - left edge
        $this->placePiece(-$this->boardSize, 0, new Piece('king', 0));
        $this->placePiece(-$this->boardSize+1, -1, new Piece('rook', 0));
        $this->placePiece(-$this->boardSize+2, -2, new Piece('knight', 0));
        $this->placePiece(-$this->boardSize+3, -3, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 1, new Piece('rook', 0));
        $this->placePiece(-$this->boardSize+1, 0, new Piece('queen', 0));
        $this->placePiece(-$this->boardSize+2, -1, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+3, -2, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 2, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+1, 1, new Piece('knight', 0));
        $this->placePiece(-$this->boardSize+2, 0, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+3, -1, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 3, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+1, 2, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+2, 1, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+3, 0, new Piece('pawn', 0));
        
        // Player 2 (Blue) - right edge
        $this->placePiece($this->boardSize, 0, new Piece('king', 1));
        $this->placePiece($this->boardSize-1, 1, new Piece('rook', 1));
        $this->placePiece($this->boardSize-2, 2, new Piece('knight', 1));
        $this->placePiece($this->boardSize-3, 3, new Piece('pawn', 1));
        $this->placePiece($this->boardSize, -1, new Piece('rook', 1));
        $this->placePiece($this->boardSize-1, 0, new Piece('queen', 1));
        $this->placePiece($this->boardSize-2, 1, new Piece('bishop', 1));
        $this->placePiece($this->boardSize-3, 2, new Piece('pawn', 1));
        $this->placePiece($this->boardSize, -2, new Piece('bishop', 1));
        $this->placePiece($this->boardSize-1, -1, new Piece('knight', 1));
        $this->placePiece($this->boardSize-2, 0, new Piece('bishop', 1));
        $this->placePiece($this->boardSize-3, 1, new Piece('pawn', 1));
        $this->placePiece($this->boardSize, -3, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-1, -2, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-2, -1, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-3, 0, new Piece('pawn', 1));
    }
    
    private function setupThreePlayerPieces() {
        // Player 1 (Red) - left edge
        $this->placePiece(-$this->boardSize, 0, new Piece('king', 0));
        $this->placePiece(-$this->boardSize+1, -1, new Piece('rook', 0));
        $this->placePiece(-$this->boardSize+2, -2, new Piece('knight', 0));
        $this->placePiece(-$this->boardSize+3, -3, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 1, new Piece('rook', 0));
        $this->placePiece(-$this->boardSize+1, 0, new Piece('queen', 0));
        $this->placePiece(-$this->boardSize+2, -1, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+3, -2, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 2, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+1, 1, new Piece('knight', 0));
        $this->placePiece(-$this->boardSize+2, 0, new Piece('bishop', 0));
        $this->placePiece(-$this->boardSize+3, -1, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize, 3, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+1, 2, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+2, 1, new Piece('pawn', 0));
        $this->placePiece(-$this->boardSize+3, 0, new Piece('pawn', 0));
        
        // Player 2 (Blue) - top-right corner
        $this->placePiece($this->boardSize, -$this->boardSize, new Piece('king', 1));
        $this->placePiece($this->boardSize-1, -$this->boardSize+1, new Piece('queen', 1));
        $this->placePiece($this->boardSize-1, -$this->boardSize, new Piece('rook', 1));
        $this->placePiece($this->boardSize, -$this->boardSize+1, new Piece('rook', 1));
        $this->placePiece($this->boardSize-2, -$this->boardSize+2, new Piece('bishop', 1));
        $this->placePiece($this->boardSize-2, -$this->boardSize+1, new Piece('knight', 1));
        $this->placePiece($this->boardSize-2, -$this->boardSize, new Piece('bishop', 1));
        $this->placePiece($this->boardSize-1, -$this->boardSize+2, new Piece('bishop', 1));
        $this->placePiece($this->boardSize, -$this->boardSize+2, new Piece('knight', 1));
        $this->placePiece($this->boardSize-3, -$this->boardSize+3, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-3, -$this->boardSize+2, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-3, -$this->boardSize+1, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-3, -$this->boardSize, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-2, -$this->boardSize+3, new Piece('pawn', 1));
        $this->placePiece($this->boardSize-1, -$this->boardSize+3, new Piece('pawn', 1));
        $this->placePiece($this->boardSize, -$this->boardSize+3, new Piece('pawn', 1));
        
        // Player 3 (Green) - bottom corner
        $this->placePiece(0, $this->boardSize, new Piece('king', 2));
        $this->placePiece(1, $this->boardSize-1, new Piece('rook', 2));
        $this->placePiece(2, $this->boardSize-2, new Piece('knight', 2));
        $this->placePiece(3, $this->boardSize-3, new Piece('pawn', 2));
        $this->placePiece(-1, $this->boardSize, new Piece('rook', 2));
        $this->placePiece(0, $this->boardSize-1, new Piece('queen', 2));
        $this->placePiece(1, $this->boardSize-2, new Piece('bishop', 2));
        $this->placePiece(2, $this->boardSize-3, new Piece('pawn', 2));
        $this->placePiece(-2, $this->boardSize, new Piece('bishop', 2));
        $this->placePiece(-1, $this->boardSize-1, new Piece('knight', 2));
        $this->placePiece(0, $this->boardSize-2, new Piece('bishop', 2));
        $this->placePiece(1, $this->boardSize-3, new Piece('pawn', 2));
        $this->placePiece(-3, $this->boardSize, new Piece('pawn', 2));
        $this->placePiece(-2, $this->boardSize-1, new Piece('pawn', 2));
        $this->placePiece(-1, $this->boardSize-2, new Piece('pawn', 2));
        $this->placePiece(0, $this->boardSize-3, new Piece('pawn', 2));
    }
    
    private function placePiece($q, $r, $piece) {
        if ($this->isValidHex($q, $r)) {
            $this->board[$q][$r] = $piece;
        }
    }
    
    private function isValidHex($q, $r) {
        return abs($q) <= $this->boardSize && 
               abs($r) <= $this->boardSize && 
               abs($q + $r) <= $this->boardSize;
    }
    
    public function getPiece($q, $r) {
        return $this->isValidHex($q, $r) ? ($this->board[$q][$r] ?? null) : null;
    }
    
    public function getBoardSize() {
        return $this->boardSize;
    }
    
    // ENHANCED: Improved path checking for hexagonal coordinates
    private function isPathClear($fromQ, $fromR, $toQ, $toR) {
        $dq = $toQ - $fromQ;
        $dr = $toR - $fromR;
        
        $gcd = $this->gcd(abs($dq), abs($dr));
        if ($gcd == 0) return true;
        
        $stepQ = $dq / $gcd;
        $stepR = $dr / $gcd;
        
        for ($step = 1; $step < $gcd; $step++) {
            $checkQ = $fromQ + $stepQ * $step;
            $checkR = $fromR + $stepR * $step;
            
            if (!$this->isValidHex($checkQ, $checkR)) {
                return false;
            }
            
            if ($this->getPiece($checkQ, $checkR) !== null) {
                return false;
            }
        }
        
        return true;
    }
    
    private function gcd($a, $b) {
        if ($a == 0 && $b == 0) return 0;
        if ($a == 0) return $b;
        if ($b == 0) return $a;
        
        while ($b != 0) {
            $temp = $b;
            $b = $a % $b;
            $a = $temp;
        }
        return $a;
    }
    
    // ENHANCED: Better movement pattern detection
    private function isOrthogonalMove($dq, $dr) {
        $ds = -$dq - $dr;
        return ($dr == 0) || ($dq == 0) || ($dq == -$dr);
    }
    
    private function isDiagonalMove($dq, $dr) {
        $ds = -$dq - $dr;
        return ($dq == $dr) || ($dr == $ds) || ($dq == $ds);
    }
    
    public function movePiece($fromQ, $fromR, $toQ, $toR) {
        if (!$this->isValidMove($fromQ, $fromR, $toQ, $toR)) {
            return false;
        }
        
        $piece = $this->board[$fromQ][$fromR];
        $this->board[$toQ][$toR] = $piece;
        $this->board[$fromQ][$fromR] = null;
        
        $this->moveCount++;
        $this->checkForEliminations();
        $this->advanceToNextActivePlayer();
        
        return true;
    }
    
    private function advanceToNextActivePlayer() {
        do {
            $this->currentPlayer = ($this->currentPlayer + 1) % $this->playerCount;
        } while (!$this->activePlayers[$this->currentPlayer] && $this->getActivePlayerCount() > 1);
    }
    
    private function checkForEliminations() {
        for ($player = 0; $player < $this->playerCount; $player++) {
            if ($this->activePlayers[$player] && $this->isCheckmate($player)) {
                $this->activePlayers[$player] = false;
            }
        }
    }
    
    // ENHANCED: Improved move validation with detailed error checking
    private function isValidMove($fromQ, $fromR, $toQ, $toR) {
        $piece = $this->getPiece($fromQ, $fromR);
        
        if (!$piece) return false;
        if ($piece->player !== $this->currentPlayer || !$this->activePlayers[$this->currentPlayer]) return false;
        if (!$this->isValidHex($toQ, $toR)) return false;
        if ($fromQ === $toQ && $fromR === $toR) return false;
        
        $targetPiece = $this->getPiece($toQ, $toR);
        if ($targetPiece && $targetPiece->player === $this->currentPlayer) return false;
        
        if (!$this->canPieceMoveTo($piece, $fromQ, $fromR, $toQ, $toR)) return false;
        
        if ($this->moveCount >= 2) {
            if ($this->wouldLeaveKingInCheck($fromQ, $fromR, $toQ, $toR, $this->currentPlayer)) {
                return false;
            }
        }
        
        return true;
    }
    
    // ENHANCED: Better piece movement logic
    private function canPieceMoveTo($piece, $fromQ, $fromR, $toQ, $toR) {
        $dq = $toQ - $fromQ;
        $dr = $toR - $fromR;
        
        switch ($piece->type) {
            case 'pawn':
                return $this->canPawnMove($piece, $fromQ, $fromR, $toQ, $toR);
                
            case 'rook':
                return $this->isOrthogonalMove($dq, $dr) && $this->isPathClear($fromQ, $fromR, $toQ, $toR);
                
            case 'bishop':
                return $this->isDiagonalMove($dq, $dr) && $this->isPathClear($fromQ, $fromR, $toQ, $toR);
                
            case 'knight':
                $knightMoves = [
                    [2, 1], [3, -1], [1, 2], [-1, 3], [-2, 3], [-3, 2],
                    [-3, 1], [-2, -1], [-1, -2], [1, -3], [2, -3], [3, -2]
                ];
                foreach ($knightMoves as $move) {
                    list($mq, $mr) = $move;
                    if ($dq == $mq && $dr == $mr) {
                        return true;
                    }
                }
                return false;
                
            case 'queen':
                return ($this->isOrthogonalMove($dq, $dr) || $this->isDiagonalMove($dq, $dr)) && 
                       $this->isPathClear($fromQ, $fromR, $toQ, $toR);
                
            case 'king':
                // FIXED: King can move like rook (6 directions) + bishop (6 directions) = 12 total
                
                // Check orthogonal moves (rook-like): exactly 6 moves at distance 1
                if ($this->isOrthogonalMove($dq, $dr)) {
                    $ds = -$dq - $dr;
                    return max(abs($dq), abs($dr), abs($ds)) == 1;
                }
                
                // Check diagonal moves (bishop-like): exactly 6 specific diagonal moves
                if ($this->isDiagonalMove($dq, $dr)) {
                    // Allow the 6 basic diagonal moves: (1,1), (-1,-1), (-2,1), (2,-1), (1,-2), (-1,2)
                    $validDiagonals = [
                        [1, 1], [-1, -1],      // dq == dr condition
                        [-2, 1], [2, -1],     // dr == ds condition  
                        [1, -2], [-1, 2]      // dq == ds condition
                    ];
                    
                    foreach ($validDiagonals as $move) {
                        if ($dq == $move[0] && $dr == $move[1]) {
                            return true;
                        }
                    }
                }
                
                return false;
        }
        
        return false;
    }
    
    private function canPawnMove($piece, $fromQ, $fromR, $toQ, $toR) {
        $dq = $toQ - $fromQ;
        $dr = $toR - $fromR;
        
        if ($this->playerCount == 2) {
            if ($piece->player == 0) { // Red player
                if ($dq == 1 && $dr == 0) {
                    return !$this->getPiece($toQ, $toR);
                }
                if (($dq == 1 && $dr == 1) || ($dq == 2 && $dr == -1)) {
                    $targetPiece = $this->getPiece($toQ, $toR);
                    return $targetPiece && $targetPiece->player !== $piece->player;
                }
            } else { // Blue player
                if ($dq == -1 && $dr == 0) {
                    return !$this->getPiece($toQ, $toR);
                }
                if (($dq == -1 && $dr == -1) || ($dq == -2 && $dr == 1)) {
                    $targetPiece = $this->getPiece($toQ, $toR);
                    return $targetPiece && $targetPiece->player !== $piece->player;
                }
            }
        } else {
            // 3-player pawn movement
            if ($piece->player == 0) { // Red
                if ($dq == 1 && $dr == 0) {
                    return !$this->getPiece($toQ, $toR);
                }
                if (($dq == 1 && $dr == 1) || ($dq == 2 && $dr == -1)) {
                    $targetPiece = $this->getPiece($toQ, $toR);
                    return $targetPiece && $targetPiece->player !== $piece->player;
                }
            } else if ($piece->player == 1) { // Blue
                if ($dq == -1 && $dr == 1) {
                    return !$this->getPiece($toQ, $toR);
                }
                if (($dq == -1 && $dr == 0) || ($dq == -2 && $dr == 2)) {
                    $targetPiece = $this->getPiece($toQ, $toR);
                    return $targetPiece && $targetPiece->player !== $piece->player;
                }
            } else { // Green
                if ($dq == 0 && $dr == -1) {
                    return !$this->getPiece($toQ, $toR);
                }
                if (($dq == 1 && $dr == -1) || ($dq == -1 && $dr == -2)) {
                    $targetPiece = $this->getPiece($toQ, $toR);
                    return $targetPiece && $targetPiece->player !== $piece->player;
                }
            }
        }
        
        return false;
    }
    
    // ENHANCED: Better check detection
    public function wouldLeaveKingInCheck($fromQ, $fromR, $toQ, $toR, $player) {
        $piece = $this->board[$fromQ][$fromR];
        $capturedPiece = $this->board[$toQ][$toR];
        
        $this->board[$toQ][$toR] = $piece;
        $this->board[$fromQ][$fromR] = null;
        
        $inCheck = $this->isKingInCheck($player);
        
        $this->board[$fromQ][$fromR] = $piece;
        $this->board[$toQ][$toR] = $capturedPiece;
        
        return $inCheck;
    }
    
    private function findKing($player) {
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                $piece = $this->getPiece($q, $r);
                if ($piece && $piece->type === 'king' && $piece->player === $player) {
                    return ['q' => $q, 'r' => $r];
                }
            }
        }
        return null;
    }
    
    public function isKingInCheck($player) {
        $kingPos = $this->findKing($player);
        if (!$kingPos) return false;
        
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                $piece = $this->getPiece($q, $r);
                if ($piece && $piece->player !== $player) {
                    if ($this->canPieceMoveTo($piece, $q, $r, $kingPos['q'], $kingPos['r'])) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    // ENHANCED: Better valid moves calculation
    public function getValidMoves($fromQ, $fromR) {
        $piece = $this->getPiece($fromQ, $fromR);
        
        if (!$piece || $piece->player !== $this->currentPlayer) {
            return [];
        }
        
        $validMoves = [];
        
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                if ($q == $fromQ && $r == $fromR) continue;
                if (!$this->isValidHex($q, $r)) continue;
                
                if ($this->isValidMoveForPlayer($fromQ, $fromR, $q, $r, $piece->player)) {
                    $validMoves[] = ['q' => $q, 'r' => $r];
                }
            }
        }
        
        return $validMoves;
    }
    
    // NEW: Demo version that ignores turn restrictions
    public function getDemoValidMoves($fromQ, $fromR) {
        $piece = $this->getPiece($fromQ, $fromR);
        
        if (!$piece) {
            return [];
        }
        
        $validMoves = [];
        
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                if ($q == $fromQ && $r == $fromR) continue;
                if (!$this->isValidHex($q, $r)) continue;
                
                // Check basic movement rules without turn/check restrictions
                if ($this->isDemoValidMove($fromQ, $fromR, $q, $r)) {
                    $validMoves[] = ['q' => $q, 'r' => $r];
                }
            }
        }
        
        return $validMoves;
    }
    
    // NEW: Demo move validation (relaxed rules)
    private function isDemoValidMove($fromQ, $fromR, $toQ, $toR) {
        $piece = $this->getPiece($fromQ, $fromR);
        
        if (!$piece) return false;
        if (!$this->isValidHex($toQ, $toR)) return false;
        if ($fromQ === $toQ && $fromR === $toR) return false;
        
        // Allow capturing own pieces for demo purposes
        $targetPiece = $this->getPiece($toQ, $toR);
        
        // Check if piece can move to destination
        return $this->canPieceMoveTo($piece, $fromQ, $fromR, $toQ, $toR);
    }
    
    // NEW: Clear board for demo
    public function clearBoard() {
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                $this->board[$q][$r] = null;
            }
        }
    }
    
    // NEW: Place piece for demo
    public function placeDemoPiece($q, $r, $piece) {
        if ($this->isValidHex($q, $r)) {
            $this->board[$q][$r] = $piece;
        }
    }
    
    private function isValidMoveForPlayer($fromQ, $fromR, $toQ, $toR, $player) {
        $piece = $this->getPiece($fromQ, $fromR);
        
        if (!$piece || $piece->player !== $player) return false;
        if (!$this->isValidHex($toQ, $toR)) return false;
        if ($fromQ === $toQ && $fromR === $toR) return false;
        
        $targetPiece = $this->getPiece($toQ, $toR);
        if ($targetPiece && $targetPiece->player === $player) return false;
        
        if (!$this->canPieceMoveTo($piece, $fromQ, $fromR, $toQ, $toR)) return false;
        
        if ($this->moveCount >= 2) {
            if ($this->wouldLeaveKingInCheck($fromQ, $fromR, $toQ, $toR, $player)) {
                return false;
            }
        }
        
        return true;
    }
    
    public function hasLegalMoves($player) {
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                $piece = $this->getPiece($q, $r);
                if ($piece && $piece->player === $player) {
                    $validMoves = $this->getValidMovesForPiece($q, $r);
                    if (count($validMoves) > 0) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    private function getValidMovesForPiece($fromQ, $fromR) {
        $piece = $this->getPiece($fromQ, $fromR);
        if (!$piece) return [];
        
        $validMoves = [];
        
        for ($q = -$this->boardSize; $q <= $this->boardSize; $q++) {
            for ($r = max(-$this->boardSize, -$q - $this->boardSize); 
                 $r <= min($this->boardSize, -$q + $this->boardSize); $r++) {
                
                if ($q == $fromQ && $r == $fromR) continue;
                if (!$this->isValidHex($q, $r)) continue;
                
                if ($this->isValidMoveForPlayer($fromQ, $fromR, $q, $r, $piece->player)) {
                    $validMoves[] = ['q' => $q, 'r' => $r];
                }
            }
        }
        
        return $validMoves;
    }
    
    public function isCheckmate($player) {
        return $this->isKingInCheck($player) && !$this->hasLegalMoves($player);
    }
    
    public function isStalemate($player) {
        return !$this->isKingInCheck($player) && !$this->hasLegalMoves($player);
    }
    
    public function getCurrentPlayer() {
        return $this->players[$this->currentPlayer];
    }
    
    public function getCurrentPlayerSlot() {
        return $this->currentPlayer;
    }
    
    public function getPlayerCount() {
        return $this->playerCount;
    }
    
    public function getPlayers() {
        return $this->players;
    }
    
    public function getCellColor($q, $r) {
        $colorIndex = (($q - $r) % 3 + 3) % 3;
        $colors = ['pastel-red', 'pastel-green', 'pastel-blue'];
        return $colors[$colorIndex];
    }
    
    // ENHANCED: Better game state with check highlighting
    public function getGameState() {
        $activePlayerCount = $this->getActivePlayerCount();
        $gameOver = $activePlayerCount <= 1;
        $winner = null;
        
        if ($gameOver && $activePlayerCount == 1) {
            // Find the last active player as winner
            for ($player = 0; $player < $this->playerCount; $player++) {
                if ($this->activePlayers[$player]) {
                    $winner = $this->playerUsers[$player];
                    break;
                }
            }
        } elseif ($gameOver && $activePlayerCount == 0) {
            // All players resigned or eliminated - no winner
            $winner = null;
        }
        
        // Find kings in check for highlighting
        $kingsInCheck = [];
        for ($player = 0; $player < $this->playerCount; $player++) {
            if ($this->activePlayers[$player]) {
                $kingPos = $this->findKing($player);
                if ($kingPos && $this->isKingInCheck($player)) {
                    $kingsInCheck[] = $kingPos;
                }
            }
        }
        
        return [
            'gameId' => $this->gameId,
            'currentPlayer' => $this->currentPlayer,
            'playerCount' => $this->playerCount,
            'moveCount' => $this->moveCount,
            'board' => $this->board,
            'gameStatus' => [
                'gameOver' => $gameOver,
                'winner' => $winner,
                'activePlayerCount' => $activePlayerCount
            ],
            'activePlayers' => $this->activePlayers,
            'playerUsers' => $this->playerUsers,
            'isInCheck' => $this->activePlayers[$this->currentPlayer] ? $this->isKingInCheck($this->currentPlayer) : false,
            'kingsInCheck' => $kingsInCheck
        ];
    }
}