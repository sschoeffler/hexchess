console.log('🚀 COMPLETE game.js loaded');

// Global variables
let selectedHex = null;

// Auth functions
function showAuth(type) {
    document.getElementById('loginForm').style.display = type === 'login' ? 'block' : 'none';
    document.getElementById('registerForm').style.display = type === 'register' ? 'block' : 'none';
}

function login(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'login');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification('Login Failed', data.error, 'error');
        }
    });
}

function register(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'register');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification('Registration Failed', data.error, 'error');
        }
    });
}

function logout() {
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=logout'
    })
    .then(() => location.reload());
}

// Game creation
function createGame(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'create_game');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `?page=game&id=${data.game_id}`;
        } else {
            showNotification('Failed to Create Game', data.error, 'error');
        }
    });
}

// Game joining
function joinGame(gameId) {
    console.log('🎮 Joining game:', gameId);
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=join_game&game_id=${gameId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `?page=game&id=${gameId}`;
        } else {
            showNotification('Failed to Join', data.error, 'error');
        }
    });
}

// Resign game functionality
function resignGame() {
    if (!confirm('⚠️ Are you sure you want to resign?\n\nThis will end the game and count as a loss for you. This action cannot be undone.')) {
        return;
    }
    
    console.log('🏳️ Resigning from game:', gameId);
    
    const resignBtn = document.querySelector('button[onclick="resignGame()"]');
    if (resignBtn) {
        resignBtn.disabled = true;
        resignBtn.textContent = '🏳️ Resigning...';
    }
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=resign&game_id=${gameId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Game Resigned', data.message || 'You have resigned from the game', 'info');
        } else {
            showNotification('Resignation Failed', data.error, 'error');
            if (resignBtn) {
                resignBtn.disabled = false;
                resignBtn.textContent = '🏳️ Resign Game';
            }
        }
    })
    .catch(error => {
        console.error('❌ Resignation error:', error);
        showNotification('Connection Error', 'Unable to resign from game', 'error');
        if (resignBtn) {
            resignBtn.disabled = false;
            resignBtn.textContent = '🏳️ Resign Game';
        }
    });
}

function loadAvailableGames() {
    console.log('🔍 Loading available games...');
    
    fetch(window.location.pathname + '?api=games')
        .then(response => {
            console.log('📡 Response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(games => {
            console.log('✅ Games loaded successfully:', games.length, 'games');
            
            const gameList = document.getElementById('available-games');
            if (!gameList) {
                console.error('❌ gameList element not found');
                return;
            }
            
            if (games.length === 0) {
                gameList.innerHTML = '<p>No games available. Create one!</p>';
                return;
            }
            
            const gameHtml = games.map(game => `
                <div class="game-item">
                    <div class="game-info">
                        <h3>${game.game_name}</h3>
                        <p>${game.current_players}/${game.player_count} players • Created by ${game.creator}</p>
                    </div>
                    <button class="btn" onclick="joinGame('${game.game_id}')">Join</button>
                </div>
            `).join('');
            
            gameList.innerHTML = gameHtml;
            console.log('✅ Game list updated in DOM');
        })
        .catch(error => {
            console.error('❌ Error loading games:', error);
            const gameList = document.getElementById('available-games');
            if (gameList) {
                gameList.innerHTML = '<p>Error loading games. Check console.</p>';
            }
        });
}

// Load user's active games
function loadMyGames() {
    console.log('🎯 Loading my active games...');
    
    fetch(window.location.pathname + '?api=my-games')
        .then(response => {
            console.log('📡 My games response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error('❌ Error from server:', data.error);
                const gameList = document.getElementById('my-games');
                if (gameList) {
                    gameList.innerHTML = '<p>Error: ' + data.error + '</p>';
                }
                return;
            }
            
            const games = data;
            console.log('✅ My games loaded successfully:', games.length, 'games');
            
            const gameList = document.getElementById('my-games');
            if (!gameList) {
                console.error('❌ my-games element not found');
                return;
            }
            
            if (games.length === 0) {
                gameList.innerHTML = '<p>No active games. Join or create one!</p>';
                return;
            }
            
            const gameHtml = games.map(game => {
                let statusText = '';
                let buttonText = '';
                let buttonClass = 'btn';
                
                if (game.status === 'waiting') {
                    statusText = `Waiting for ${game.player_count - game.current_players} more player(s)`;
                    buttonText = 'Enter Waiting Room';
                } else if (game.status === 'active') {
                    statusText = game.is_your_turn ? 'Your turn!' : 'Waiting for other player';
                    buttonText = 'Resume Game';
                    buttonClass = game.is_your_turn ? 'btn' : 'btn btn-secondary';
                } else if (game.status === 'finished') {
                    statusText = game.winner_name ? `Won by ${game.winner_name}` : 'Game ended';
                    buttonText = 'View Game';
                    buttonClass = 'btn btn-secondary';
                }
                
                return `
                    <div class="game-item ${game.is_your_turn ? 'your-turn' : ''}">
                        <div class="game-info">
                            <h3>${game.game_name}</h3>
                            <p>${statusText}</p>
                            <small>${game.current_players}/${game.player_count} players • ${game.status}</small>
                        </div>
                        <button class="${buttonClass}" onclick="resumeGame('${game.game_id}')">${buttonText}</button>
                    </div>
                `;
            }).join('');
            
            gameList.innerHTML = gameHtml;
            console.log('✅ My games list updated in DOM');
        })
        .catch(error => {
            console.error('❌ Error loading my games:', error);
            const gameList = document.getElementById('my-games');
            if (gameList) {
                gameList.innerHTML = '<p>Error loading your games. Try refreshing.</p>';
            }
        });
}

// Resume/enter a game the user is already in
function resumeGame(gameId) {
    console.log('🎮 Resuming game:', gameId);
    window.location.href = `?page=game&id=${gameId}`;
}

// Handle game mode changes
function updateGameModeOptions() {
    const gameMode = document.getElementById('game_mode');
    const playersGroup = document.getElementById('players-group');
    const aiDifficultyGroup = document.getElementById('ai-difficulty-group');
    
    if (!gameMode || !playersGroup || !aiDifficultyGroup) {
        return; // Elements don't exist yet
    }
    
    console.log('🎮 Game mode changed to:', gameMode.value);
    
    if (gameMode.value === 'ai') {
        playersGroup.style.display = 'none';
        aiDifficultyGroup.style.display = 'block';
        
        // Set AI games to 2-player by default
        const playerCount = document.getElementById('player_count');
        if (playerCount) {
            playerCount.value = '2';
        }
    } else {
        playersGroup.style.display = 'block';
        aiDifficultyGroup.style.display = 'none';
    }
    
    updateDefaultGameName();
}

function updateDefaultGameName() {
    const gameNameInput = document.getElementById('game_name');
    const playerCount = document.getElementById('player_count');
    const boardSize = document.getElementById('board_size');
    const gameMode = document.getElementById('game_mode');
    const aiDifficulty = document.getElementById('ai_difficulty');
    
    if (!gameNameInput || !boardSize) return;
    
    const currentValue = gameNameInput.value;
    const isDefaultPattern = /^(2|3)-Player (Small|Medium|Large|Jumbo) Game$/.test(currentValue) ||
                           /^vs AI \((Easy|Medium|Hard)\) (Small|Medium|Large|Jumbo) Game$/.test(currentValue);
    
    if (isDefaultPattern || currentValue === '') {
        const sizeNames = {
            '5': 'Small', '6': 'Medium', '7': 'Large', '8': 'Jumbo'
        };
        
        let defaultName;
        if (gameMode && gameMode.value === 'ai' && aiDifficulty) {
            const difficultyNames = {
                'easy': 'Easy', 'medium': 'Medium', 'hard': 'Hard'
            };
            defaultName = `vs AI (${difficultyNames[aiDifficulty.value]}) ${sizeNames[boardSize.value]} Game`;
        } else if (playerCount) {
            defaultName = `${playerCount.value}-Player ${sizeNames[boardSize.value]} Game`;
        }
        
        if (defaultName) {
            gameNameInput.value = defaultName;
        }
    }
}

function resetToDefaultName() {
    const playerCount = document.getElementById('player_count').value;
    const boardSize = document.getElementById('board_size').value;
    const gameNameInput = document.getElementById('game_name');
    
    const sizeNames = {
        '5': 'Small',
        '6': 'Medium', 
        '7': 'Large',
        '8': 'Jumbo'
    };
    
    const defaultName = `${playerCount}-Player ${sizeNames[boardSize]} Game`;
    gameNameInput.value = defaultName;
    
    showNotification('✅ Name Reset', 'Game name reset to default', 'success');
}

function showNotification(title, message, type = 'error') {
    console.log(`📢 Notification: ${title} - ${message}`);
    
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-title">${title}</div>
        <div class="notification-message">${message}</div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('show'), 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Game-specific JavaScript
function selectHex(q, r) {
    console.log('🎯 selectHex called:', q, r, 'gameId:', typeof gameId !== 'undefined' ? gameId : 'UNDEFINED');
    
    if (typeof userCanMove !== 'undefined' && !userCanMove) {
        showNotification('Not Your Turn', 'Wait for your turn to move', 'warning');
        return;
    }
    
    const cell = document.querySelector(`[data-q="${q}"][data-r="${r}"]`);
    if (!cell) {
        console.error('❌ Cell not found for coordinates:', q, r);
        return;
    }
    
    // If clicking the same hex, deselect it
    if (selectedHex && selectedHex.q === q && selectedHex.r === r) {
        clearSelection();
        return;
    }
    
    // If we have a selected piece and clicked on a valid move, make the move
    if (selectedHex && cell.classList.contains('valid-move')) {
        makeMove(selectedHex.q, selectedHex.r, q, r);
        return;
    }
    
    // Check if there's actually a piece at this position
    const piece = cell.querySelector('.piece');
    if (!piece) {
        clearSelection();
        return; // No piece here, don't show any moves
    }
    
    // Select this piece and show its valid moves
    clearSelection();
    selectedHex = {q: q, r: r};
    cell.classList.add('selected');
    
    if (typeof gameId !== 'undefined') {
        getValidMoves(q, r);
    } else {
        // For demo mode, highlight some example moves
        highlightValidMoves(q, r);
    }
}

function clearSelection() {
    document.querySelectorAll('.hex-cell').forEach(cell => {
        cell.classList.remove('selected', 'valid-move');
    });
    selectedHex = null;
}

function clearCheckHighlights() {
    document.querySelectorAll('.hex-cell').forEach(cell => {
        cell.classList.remove('king-in-check');
    });
}

function highlightValidMoves(q, r) {
    const directions = [
        [1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1],
        [2, -1], [1, -2], [-1, -1], [-2, 1], [-1, 2], [1, 1]
    ];
    
    directions.forEach(([dq, dr]) => {
        const newQ = q + dq;
        const newR = r + dr;
        const targetCell = document.querySelector(`[data-q="${newQ}"][data-r="${newR}"]`);
        if (targetCell) {
            targetCell.classList.add('valid-move');
        }
    });
}

function getValidMoves(q, r) {
    console.log('🎯 Getting valid moves for:', q, r, 'gameId:', gameId);
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=getValidMoves&game_id=${gameId}&fromQ=${q}&fromR=${r}`
    })
    .then(response => response.json())
    .then(data => {
        console.log('📡 Server response:', data);
        
        if (data.success && data.validMoves && data.validMoves.length > 0) {
            console.log('✅ Found', data.validMoves.length, 'valid moves');
            data.validMoves.forEach(move => {
                const targetCell = document.querySelector(`[data-q="${move.q}"][data-r="${move.r}"]`);
                if (targetCell) {
                    targetCell.classList.add('valid-move');
                }
            });
        } else {
            console.log('❌ No valid moves or error:', data);
            clearSelection();
        }
    })
    .catch(error => {
        console.error('❌ Fetch error:', error);
        clearSelection();
    });
}

function makeMove(fromQ, fromR, toQ, toR) {
    console.log('🎯 Making move:', fromQ, fromR, '→', toQ, toR);
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=move&game_id=${gameId}&fromQ=${fromQ}&fromR=${fromR}&toQ=${toQ}&toR=${toR}`
    })
    .then(response => response.json())
    .then(data => {
        console.log('📡 Move response:', data);
        
        if (data.success) {
            // No notification for successful moves - just reload
            console.log('✅ Move successful');
            
            // If it's an AI game, trigger AI move after human move
            if (isAIGameEnhanced()) {
                console.log('🤖 AI game detected, will trigger AI move after reload');
                
                // Force page reload to show updated board, then trigger AI
                setTimeout(() => {
                    location.reload();
                }, 800);
            } else {
                // Regular game, just reload
                setTimeout(() => {
                    location.reload();
                }, 800);
            }
            
        } else {
            // Only show notifications for errors
            if (data.errorType === 'exposes-king') {
                showNotification('⚠️ King in Danger!', 'That move would expose your king to check', 'warning');
            } else if (data.errorType === 'wrong-player') {
                showNotification('❌ Wrong Piece', 'You can only move your own pieces', 'error');
            } else if (data.errorType === 'no-piece') {
                showNotification('❌ No Piece', 'No piece at selected position', 'error');
            } else {
                showNotification('❌ Invalid Move', data.error || 'Move not allowed', 'error');
            }
        }
        clearSelection();
    })
    .catch(error => {
        console.error('❌ Move error:', error);
        showNotification('❌ Connection Error', 'Unable to make move', 'error');
        clearSelection();
    });
}

// Call this function after board updates to reapply hover effects
function refreshBoardEvents() {
    console.log('🔄 Refreshing board events...');
    applyHoverEffects();
    
    // Check for AI move after refresh
    if (isAIGameEnhanced()) {
        autoTriggerAI();
    }
}

// Check if it's the AI's turn and trigger AI move
function checkForAIMove() {
    // Only check for AI moves if we have gameId defined (not in demo mode) or force mode
    if (typeof gameId === 'undefined' && !window.forceAIMode) {
        console.log('🤖 No gameId and not forced, skipping server AI check');
        // Try client-side AI anyway
        makeClientSideAIMove();
        return;
    }
    
    console.log('🤖 Checking for AI move...');
    
    // Show AI thinking indicator
    showAIThinking();
    
    // Add a small delay to make the AI move feel more natural
    setTimeout(() => {
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=ai_move&game_id=${gameId}`
        })
        .then(response => response.json())
        .then(data => {
            hideAIThinking();
            
            if (data.success) {
                console.log('🤖 AI made move successfully');
                
                // Force page reload to show AI move (no notification needed)
                setTimeout(() => {
                    location.reload();
                }, 1000);
                
            } else {
                // If server AI fails, try client-side AI
                if (data.error && (data.error.includes('Not implemented') || 
                                  data.error.includes('AI not found') ||
                                  data.error.includes('No AI'))) {
                    console.log('🤖 Server AI not available, using client-side AI...');
                    makeClientSideAIMove();
                } else if (data.error && !data.error.includes('Not AI') && 
                          !data.error.includes('Not an AI game') &&
                          !data.error.includes('wrong turn')) {
                    console.error('🤖 AI move error:', data.error);
                    // Still try client-side as fallback
                    console.log('🤖 Trying client-side AI as fallback...');
                    makeClientSideAIMove();
                } else {
                    console.log('🤖 Not AI turn or not AI game');
                }
            }
        })
        .catch(error => {
            hideAIThinking();
            console.error('🤖 AI move fetch error:', error);
            // Fallback to client-side AI
            console.log('🤖 Falling back to client-side AI...');
            makeClientSideAIMove();
        });
    }, 1500); // 1.5 second delay
}

// Client-side AI implementation
function makeClientSideAIMove() {
    console.log('🤖 Starting client-side AI move...');
    
    if (typeof gameId === 'undefined' && !window.forceAIMode) {
        console.log('🤖 No gameId and not forced mode, skipping AI move');
        return;
    }
    
    // Show AI thinking
    showAIThinking();
    
    // Get current board state
    const boardState = getBoardState();
    if (!boardState) {
        hideAIThinking();
        console.error('🤖 Could not get board state');
        return;
    }
    
    console.log('🤖 Board state found:', boardState.pieces.length, 'pieces');
    
    // Determine AI difficulty (default to medium if not specified)
    const aiDifficulty = getAIDifficulty() || 'medium';
    console.log('🤖 AI Difficulty:', aiDifficulty);
    
    // Calculate AI move
    setTimeout(() => {
        const aiMove = calculateAIMove(boardState, aiDifficulty);
        
        if (aiMove) {
            console.log('🤖 AI calculated move:', aiMove);
            
            // Make the move
            if (typeof gameId !== 'undefined') {
                // Real game - use server move (no extra notification)
                makeMove(aiMove.fromQ, aiMove.fromR, aiMove.toQ, aiMove.toR);
            } else {
                // Demo mode - simulate move visually
                simulateAIMoveVisually(aiMove);
            }
        } else {
            hideAIThinking();
            console.log('🤖 AI could not find a valid move');
            showNotification('🤖 AI Stuck', 'AI cannot find a valid move', 'warning');
        }
    }, 1000 + Math.random() * 2000); // Random thinking time 1-3 seconds
}

// Simulate AI move visually for demo purposes
function simulateAIMoveVisually(move) {
    console.log('🎭 Simulating AI move visually:', move);
    
    // Find the piece to move
    const fromCell = document.querySelector(`[data-q="${move.fromQ}"][data-r="${move.fromR}"]`);
    const toCell = document.querySelector(`[data-q="${move.toQ}"][data-r="${move.toR}"]`);
    
    if (fromCell && toCell) {
        const piece = fromCell.querySelector('.piece');
        const targetPiece = toCell.querySelector('.piece');
        
        if (piece) {
            // Remove piece from original position
            piece.remove();
            
            // Remove captured piece if any
            if (targetPiece) {
                targetPiece.remove();
                console.log('🤖 AI captured a piece');
            }
            
            // Add piece to new position
            const toContent = toCell.querySelector('.hex-content');
            if (toContent) {
                toContent.appendChild(piece);
                
                // Highlight the move briefly
                fromCell.classList.add('valid-move');
                toCell.classList.add('selected');
                
                setTimeout(() => {
                    fromCell.classList.remove('valid-move');
                    toCell.classList.remove('selected');
                }, 2000);
            }
        }
    }
    
    hideAIThinking();
    console.log('✅ AI move complete');
}

// Get current board state from DOM
function getBoardState() {
    const pieces = [];
    const cells = document.querySelectorAll('.hex-cell');
    
    cells.forEach(cell => {
        const piece = cell.querySelector('.piece');
        if (piece) {
            const q = parseInt(cell.getAttribute('data-q'));
            const r = parseInt(cell.getAttribute('data-r'));
            const isRed = piece.classList.contains('red-piece');
            const isBlue = piece.classList.contains('blue-piece');
            const pieceType = getPieceType(piece.textContent);
            
            pieces.push({
                q: q,
                r: r,
                type: pieceType,
                player: isRed ? 'red' : (isBlue ? 'blue' : 'unknown'),
                element: piece
            });
        }
    });
    
    return { pieces };
}

// Determine piece type from Unicode symbol
function getPieceType(symbol) {
    const pieceMap = {
        '♚': 'king', '♛': 'queen', '♜': 'rook',
        '♝': 'bishop', '♞': 'knight', '♟': 'pawn',
        '♔': 'king', '♕': 'queen', '♖': 'rook',
        '♗': 'bishop', '♘': 'knight', '♙': 'pawn'
    };
    return pieceMap[symbol] || 'unknown';
}

// Get AI difficulty from page or default
function getAIDifficulty() {
    // Try to get from form first
    const difficultySelect = document.getElementById('ai_difficulty');
    if (difficultySelect) {
        return difficultySelect.value;
    }
    
    // Check URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const difficulty = urlParams.get('difficulty');
    if (difficulty) {
        return difficulty;
    }
    
    // Default to medium
    return 'medium';
}

// Main AI move calculation
function calculateAIMove(boardState, difficulty) {
    console.log('🧠 Calculating AI move with difficulty:', difficulty);
    
    // Find AI player pieces (assume AI is blue player for now)
    const aiPieces = boardState.pieces.filter(piece => piece.player === 'blue');
    const enemyPieces = boardState.pieces.filter(piece => piece.player === 'red');
    
    if (aiPieces.length === 0) {
        console.log('🤖 No AI pieces found');
        return null;
    }
    
    // Get all possible moves for AI pieces
    const allMoves = [];
    
    aiPieces.forEach(piece => {
        const moves = getValidMovesForPiece(piece.type, piece.q, piece.r);
        moves.forEach(move => {
            if (isValidMoveOnBoard(piece.q, piece.r, move.q, move.r, boardState)) {
                allMoves.push({
                    fromQ: piece.q,
                    fromR: piece.r,
                    toQ: move.q,
                    toR: move.r,
                    piece: piece,
                    moveType: move.type,
                    score: 0
                });
            }
        });
    });
    
    if (allMoves.length === 0) {
        console.log('🤖 No valid moves found');
        return null;
    }
    
    // Score moves based on difficulty
    allMoves.forEach(move => {
        move.score = scoreMoveByDifficulty(move, boardState, difficulty);
    });
    
    // Select move based on difficulty
    return selectMoveByDifficulty(allMoves, difficulty);
}

// Check if a move is valid on the current board
function isValidMoveOnBoard(fromQ, fromR, toQ, toR, boardState) {
    // Check if target position is within board bounds
    if (!isValidHex(toQ, toR)) {
        return false;
    }
    
    // Check if target position is occupied by own piece
    const targetPiece = boardState.pieces.find(p => p.q === toQ && p.r === toR);
    const movingPiece = boardState.pieces.find(p => p.q === fromQ && p.r === fromR);
    
    if (targetPiece && targetPiece.player === movingPiece.player) {
        return false; // Can't capture own piece
    }
    
    return true;
}

// Score moves based on AI difficulty
function scoreMoveByDifficulty(move, boardState, difficulty) {
    let score = 0;
    
    // Base scoring
    const targetPiece = boardState.pieces.find(p => p.q === move.toQ && p.r === move.toR);
    
    // Capture scoring
    if (targetPiece && targetPiece.player !== move.piece.player) {
        const pieceValues = {
            'pawn': 1, 'knight': 3, 'bishop': 3,
            'rook': 5, 'queen': 9, 'king': 100
        };
        score += pieceValues[targetPiece.type] || 0;
    }
    
    // Positional scoring (move toward center)
    const centerDistance = Math.abs(move.toQ) + Math.abs(move.toR) + Math.abs(move.toQ + move.toR);
    score += (8 - centerDistance) * 0.1;
    
    // Difficulty-specific adjustments
    switch (difficulty) {
        case 'easy':
            // Easy AI: Add randomness, prefer simple moves
            score += Math.random() * 2;
            if (move.piece.type === 'pawn') score += 0.5;
            break;
            
        case 'medium':
            // Medium AI: Balanced play with some strategy
            score += Math.random() * 1;
            // Prefer developing pieces
            if (move.piece.type === 'knight' || move.piece.type === 'bishop') {
                score += 0.3;
            }
            break;
            
        case 'hard':
            // Hard AI: More strategic, less random
            score += Math.random() * 0.5;
            // Advanced piece development
            if (move.piece.type === 'queen' || move.piece.type === 'rook') {
                score += 0.2;
            }
            // Penalize king moves unless necessary
            if (move.piece.type === 'king') {
                score -= 0.3;
            }
            break;
    }
    
    return score;
}

// Select move based on difficulty
function selectMoveByDifficulty(moves, difficulty) {
    // Sort moves by score (highest first)
    moves.sort((a, b) => b.score - a.score);
    
    switch (difficulty) {
        case 'easy':
            // Easy: Pick from top 50% of moves randomly
            const easyMoves = moves.slice(0, Math.ceil(moves.length * 0.5));
            return easyMoves[Math.floor(Math.random() * easyMoves.length)];
            
        case 'medium':
            // Medium: Pick from top 25% of moves
            const mediumMoves = moves.slice(0, Math.max(1, Math.ceil(moves.length * 0.25)));
            return mediumMoves[Math.floor(Math.random() * mediumMoves.length)];
            
        case 'hard':
            // Hard: Pick the best move with small chance of picking second best
            if (moves.length > 1 && Math.random() < 0.1) {
                return moves[1]; // 10% chance to pick second best
            }
            return moves[0]; // 90% chance to pick best move
            
        default:
            return moves[0];
    }
}

// Show AI thinking indicator
function showAIThinking() {
    // First try to find existing AI status slot
    let aiStatusSlot = document.getElementById('ai-status-slot');
    
    // If no slot exists, create one near the game status
    if (!aiStatusSlot) {
        aiStatusSlot = document.createElement('div');
        aiStatusSlot.id = 'ai-status-slot';
        aiStatusSlot.style.cssText = `
            min-height: 40px;
            margin: 10px 0;
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        
        // Try to insert it near game status
        const gameStatus = document.getElementById('gameStatusText');
        if (gameStatus) {
            gameStatus.parentNode.insertBefore(aiStatusSlot, gameStatus.nextSibling);
        } else {
            // Fallback: add to body
            document.body.appendChild(aiStatusSlot);
        }
    }
    
    // Only show thinking indicator if not already visible
    if (!aiStatusSlot.querySelector('.ai-thinking')) {
        aiStatusSlot.innerHTML = `
            <div class="ai-thinking" style="
                background: rgba(255, 255, 255, 0.95);
                color: #333;
                font-weight: bold;
                padding: 8px 12px;
                border-radius: 6px;
                border: 2px solid #4CAF50;
                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                animation: ai-pulse 1.5s infinite;
                text-align: center;
                width: 100%;
                box-sizing: border-box;
            ">
                🤖 AI is thinking...
            </div>
        `;
        
        // Add CSS animation if it doesn't exist
        if (!document.querySelector('#ai-thinking-style')) {
            const style = document.createElement('style');
            style.id = 'ai-thinking-style';
            style.textContent = `
                @keyframes ai-pulse {
                    0% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.8; transform: scale(1.02); }
                    100% { opacity: 1; transform: scale(1); }
                }
            `;
            document.head.appendChild(style);
        }
    }
}

// Hide AI thinking indicator
function hideAIThinking() {
    const aiStatusSlot = document.getElementById('ai-status-slot');
    if (aiStatusSlot) {
        // Clear the slot but keep the container
        aiStatusSlot.innerHTML = '';
    }
}

// Auto-trigger AI move when it's AI's turn
function autoTriggerAI() {
    console.log('🤖 autoTriggerAI called');
    console.log('🤖 gameId:', typeof gameId !== 'undefined' ? gameId : 'UNDEFINED');
    console.log('🤖 userCanMove:', typeof userCanMove !== 'undefined' ? userCanMove : 'UNDEFINED');
    console.log('🤖 isAIGame():', isAIGame());
    
    // Check if it's an AI game and AI's turn
    if (typeof gameId !== 'undefined' && isAIGame()) {
        console.log('🤖 This is an AI game');
        
        // If user can't move, it might be AI's turn
        if (typeof userCanMove !== 'undefined' && !userCanMove) {
            console.log('🤖 User cannot move, triggering AI...');
            
            // Small delay before checking for AI move
            setTimeout(() => {
                checkForAIMove();
            }, 2000);
        } else if (typeof userCanMove === 'undefined') {
            // If userCanMove is not defined, try to detect from game state
            console.log('🤖 userCanMove undefined, checking game state...');
            
            setTimeout(() => {
                if (shouldAIMoveNow()) {
                    console.log('🤖 AI should move now, triggering...');
                    checkForAIMove();
                } else {
                    console.log('🤖 Not AI turn yet');
                }
            }, 2000);
        } else {
            console.log('🤖 User can move, not AI turn');
        }
    } else {
        console.log('🤖 Not an AI game or no gameId');
    }
}

// Check if AI should move based on game state
function shouldAIMoveNow() {
    // Look for game status indicators
    const gameStatus = document.getElementById('gameStatusText');
    if (gameStatus) {
        const statusText = gameStatus.textContent.toLowerCase();
        console.log('🤖 Game status text:', statusText);
        
        // Check for AI turn indicators
        if (statusText.includes('ai') && 
            (statusText.includes('turn') || statusText.includes('move'))) {
            return true;
        }
        
        // Check for "waiting for" indicators that suggest it's AI turn
        if (statusText.includes('waiting') && statusText.includes('ai')) {
            return false; // Actually waiting for AI, so AI should move
        }
    }
    
    // Check for turn indicators in the page
    const turnIndicators = document.querySelectorAll('[class*="turn"], [class*="player"]');
    for (let indicator of turnIndicators) {
        const text = indicator.textContent.toLowerCase();
        if (text.includes('ai') && text.includes('turn')) {
            return true;
        }
    }
    
    // Fallback: if no clear indication, assume AI should try to move
    return true;
}

// Enhanced AI move with better error handling
function triggerAIMove() {
    console.log('🤖 Manually triggering AI move...');
    if (isAIGameEnhanced()) {
        checkForAIMove();
    } else {
        console.log('🤖 Not an AI game, creating test scenario...');
        // For testing purposes, force AI move
        makeClientSideAIMove();
    }
}

// Check if current game has AI opponent
function isAIGame() {
    console.log('🤖 Checking if this is an AI game...');
    
    // Check URL parameters for AI indicator
    const urlParams = new URLSearchParams(window.location.search);
    const gameMode = urlParams.get('mode');
    console.log('🤖 URL game mode:', gameMode);
    if (gameMode === 'ai') {
        console.log('✅ AI game detected from URL mode');
        return true;
    }
    
    // Check for AI difficulty parameter
    const difficulty = urlParams.get('difficulty');
    console.log('🤖 URL difficulty:', difficulty);
    if (difficulty && ['easy', 'medium', 'hard'].includes(difficulty)) {
        console.log('✅ AI game detected from difficulty parameter');
        return true;
    }
    
    // Check for AI indicator in page data
    const aiIndicator = document.querySelector('[data-ai-game="true"]');
    if (aiIndicator) {
        console.log('✅ AI game detected from data attribute');
        return true;
    }
    
    // Check game status text for AI mentions
    const gameStatus = document.getElementById('gameStatusText');
    if (gameStatus && gameStatus.textContent.toLowerCase().includes('ai')) {
        console.log('✅ AI game detected from status text');
        return true;
    }
    
    // Check for AI player names or indicators
    const playerElements = document.querySelectorAll('[class*="player"], [class*="name"]');
    for (let element of playerElements) {
        if (element.textContent.toLowerCase().includes('ai') || 
            element.textContent.toLowerCase().includes('bot')) {
            console.log('✅ AI game detected from player elements');
            return true;
        }
    }
    
    // Check for any element with "ai" in class name
    const aiElements = document.querySelectorAll('[class*="ai"], [class*="bot"]');
    if (aiElements.length > 0) {
        console.log('✅ AI game detected from AI elements');
        return true;
    }
    
    console.log('❌ No AI game indicators found');
    return false;
}

// Get AI player color (assumes AI is typically the second player - blue)
function getAIPlayerColor() {
    // Try to determine from game context
    // This could be enhanced based on your specific game implementation
    return 'blue'; // Default assumption
}

function highlightKingsInCheck(kingsInCheck) {
    clearCheckHighlights();
    kingsInCheck.forEach(king => {
        const kingCell = document.querySelector(`[data-q="${king.q}"][data-r="${king.r}"]`);
        if (kingCell) {
            kingCell.classList.add('king-in-check');
        }
    });
}

function updateGameState(gameState) {
    if (gameState.gameStatus.gameOver) {
        showNotification('🏁 Game Over', 'Game has ended!', 'success');
        if (typeof userCanMove !== 'undefined') {
            userCanMove = false;
        }
        
        // Hide the resign button since game is over
        const resignBtn = document.querySelector('button[onclick="resignGame()"]');
        if (resignBtn) {
            resignBtn.style.display = 'none';
        }
    }
}

// Main game functions for demo mode
function newGame() {
    if (typeof gameId === 'undefined') {
        // Demo mode
        location.reload();
    } else {
        // Real game mode
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=newgame'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

function showMovementDemo() {
    const modal = document.getElementById('demoModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeDemoModal() {
    document.getElementById('demoModal').style.display = 'none';
    const demoBoard = document.getElementById('demoBoard');
    if (demoBoard) {
        demoBoard.style.display = 'none';
        demoBoard.innerHTML = '';
    }
    document.querySelectorAll('.demo-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('demoInfo').innerHTML = '<p>Select a piece above to see its movement pattern demonstrated on the full game board.</p>';
}

// DEMO FUNCTIONS
function showPiece(pieceType) {
    console.log('🎭 showPiece called for:', pieceType);
    
    if (window.demoProcessing) {
        return;
    }
    
    window.demoProcessing = true;
    
    try {
        // Update UI
        document.querySelectorAll('.piece-nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const navButton = document.getElementById(`nav-${pieceType}`);
        if (navButton) {
            navButton.classList.add('active');
        }
        
        document.querySelectorAll('.piece-desc').forEach(desc => {
            desc.classList.remove('active');
        });
        
        const descElement = document.getElementById(`desc-${pieceType}`);
        if (descElement) {
            descElement.classList.add('active');
        }
        
        // Clear highlights
        document.querySelectorAll('.hex-cell').forEach(cell => {
            cell.classList.remove('selected', 'valid-move', 'capture-square');
        });
        
        // Update piece and show pattern
        updateBoardPiece(pieceType);
        showMovementPattern(pieceType);
        
        console.log('✅ Demo complete for:', pieceType);
        
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        setTimeout(() => {
            window.demoProcessing = false;
        }, 100);
    }
}

function updateBoardPiece(pieceType) {
    const pieceIcons = {
        'king': '♚', 'queen': '♛', 'rook': '♜',
        'bishop': '♝', 'knight': '♞', 'pawn': '♟'
    };
    
    let demoQ, demoR;
    switch (pieceType) {
        case 'pawn':
            demoQ = -5; demoR = 0;
            break;
        default:
            demoQ = 0; demoR = 0;
    }
    
    // Clear all pieces
    document.querySelectorAll('.hex-content').forEach(content => {
        content.innerHTML = '';
    });
    
    // Place new piece
    const pieceCell = document.querySelector(`[data-q="${demoQ}"][data-r="${demoR}"]`);
    if (pieceCell) {
        const pieceContent = pieceCell.querySelector('.hex-content');
        if (pieceContent) {
            pieceContent.innerHTML = `<span class='piece red-piece'>${pieceIcons[pieceType]}</span>`;
        }
    }
}

function showMovementPattern(pieceType) {
    let demoQ, demoR;
    switch (pieceType) {
        case 'pawn':
            demoQ = -5; demoR = 0;
            break;
        default:
            demoQ = 0; demoR = 0;
    }
    
    // Highlight piece position
    const pieceCell = document.querySelector(`[data-q="${demoQ}"][data-r="${demoR}"]`);
    if (pieceCell) {
        pieceCell.classList.add('selected');
    }
    
    // Get moves and highlight them
    const validMoves = getValidMovesForPiece(pieceType, demoQ, demoR);
    
    console.log(`🎯 ${pieceType} valid moves:`, validMoves.length);
    
    validMoves.forEach(move => {
        const cell = document.querySelector(`[data-q="${move.q}"][data-r="${move.r}"]`);
        if (cell) {
            if (move.type === 'capture') {
                cell.classList.add('capture-square');
            } else {
                cell.classList.add('valid-move');
            }
        }
    });
}

function getValidMovesForPiece(pieceType, fromQ, fromR) {
    const moves = [];
    
    switch (pieceType) {
        case 'pawn':
            moves.push({q: fromQ + 1, r: fromR, type: 'move'});
            moves.push({q: fromQ + 1, r: fromR + 1, type: 'capture'});
            moves.push({q: fromQ + 2, r: fromR - 1, type: 'capture'});
            break;
            
        case 'bishop':
            const bishopDirections = [
                [1, 1], [-1, -1],
                [2, -1], [-2, 1],
                [1, -2], [-1, 2]
            ];
            
            bishopDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'queen':
            const queenDirections = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1],
                [1, 1], [-1, -1], [2, -1], [-2, 1], [1, -2], [-1, 2]
            ];
            
            queenDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'rook':
            const rookDirections = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]
            ];
            
            rookDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'knight':
            const knightMoves = [
                [2, 1], [3, -1], [1, 2], [-1, 3],
                [-2, 3], [-3, 2], [-3, 1], [-2, -1],
                [-1, -2], [1, -3], [2, -3], [3, -2]
            ];
            
            knightMoves.forEach(([dq, dr]) => {
                const newQ = fromQ + dq;
                const newR = fromR + dr;
                
                if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                    moves.push({q: newQ, r: newR, type: 'move'});
                }
            });
            break;
            
        case 'king':
            const kingMoves = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1],
                [1, 1], [-1, -1], [2, -1], [-2, 1], [1, -2], [-1, 2]
            ];
            
            kingMoves.forEach(([dq, dr]) => {
                const newQ = fromQ + dq;
                const newR = fromR + dr;
                
                if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                    moves.push({q: newQ, r: newR, type: 'move'});
                }
            });
            break;
    }
    
    return moves;
}

// Auto-load demo
function initializeDemoPage() {
    console.log('🚀 Initializing demo page with king moves');
    
    setTimeout(() => {
        showPiece('king');
    }, 500);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Game.js initialized');
    
    // Demo page auto-init
    if (window.location.search.includes('page=demo')) {
        console.log('📚 Demo page detected, will auto-show king moves');
        initializeDemoPage();
    }
    
    const modal = document.getElementById('demoModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeDemoModal();
            }
        });
    }
    
    // Load available games if on lobby page
    if (document.getElementById('available-games')) {
        loadAvailableGames();
    }
    
    // Load user's games if on lobby page
    if (document.getElementById('my-games')) {
        loadMyGames();
    }

    // Apply hover effects to all hex cells (for pieces)
    applyHoverEffects();
    
    // Auto-trigger AI move if it's an AI game and AI's turn
    if (isAIGameEnhanced()) {
        console.log('🤖 AI game detected, will check for AI turn...');
        autoTriggerAI();
        
        // Set up periodic AI checks
        setInterval(() => {
            if (isAIGameEnhanced() && shouldAIMoveNow()) {
                console.log('🤖 Periodic AI check: triggering AI move');
                checkForAIMove();
            }
        }, 5000); // Check every 5 seconds
    }
    
    // Always add AI test buttons for debugging
    addAITestButton();
    
    // Keyboard event listeners
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('demoModal');
            const demoBoard = document.getElementById('demoBoard');
            if (modal && modal.style.display === 'flex') {
                if (demoBoard && demoBoard.style.display === 'block') {
                    demoBoard.style.display = 'none';
                    demoBoard.innerHTML = '';
                    document.querySelectorAll('.demo-btn').forEach(btn => btn.classList.remove('active'));
                    document.getElementById('demoInfo').innerHTML = '<p>Select a piece above to see its movement pattern demonstrated on the full game board.</p>';
                } else {
                    closeDemoModal();
                }
            } else {
                clearSelection();
            }
        }
        
        // Developer shortcut: Press 'T' to trigger AI move manually
        if (e.key === 't' || e.key === 'T') {
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                console.log('🤖 Manual AI trigger (Ctrl+T)');
                triggerAIMove();
            }
        }
        
        // Debug shortcut: Press 'D' for AI debug info
        if (e.key === 'd' || e.key === 'D') {
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                console.log('🔍 AI Debug trigger (Ctrl+D)');
                debugAI();
            }
        }
    });
});

// Function to apply hover effects to hex cells
function applyHoverEffects() {
    document.querySelectorAll('.hex-cell').forEach(cell => {
        // Remove any existing event listeners to prevent duplicates
        cell.removeEventListener('mouseenter', handlePieceHover);
        cell.removeEventListener('mouseleave', handlePieceLeave);
        
        // Add the hover event listeners
        cell.addEventListener('mouseenter', handlePieceHover);
        cell.addEventListener('mouseleave', handlePieceLeave);
    });
}

function handlePieceHover() {
    const piece = this.querySelector('.piece');
    if (piece) {
        // Combine centering AND scaling transforms
        piece.style.transform = 'translate(-50%, -50%) scale(1.15)';
        piece.style.transition = 'transform 0.2s ease';
    }
}

function handlePieceLeave() {
    const piece = this.querySelector('.piece');
    if (piece) {
        // Reset to just centering transform
        piece.style.transform = 'translate(-50%, -50%) scale(1)';
    }
}

// Helper functions
function isValidHex(q, r) {
    const BOARD_SIZE = 8;
    return Math.abs(q) <= BOARD_SIZE && 
           Math.abs(r) <= BOARD_SIZE && 
           Math.abs(q + r) <= BOARD_SIZE;
}

function getCellColor(q, r) {
    const colorIndex = ((q - r) % 3 + 3) % 3;
    const colors = ['pastel-red', 'pastel-green', 'pastel-blue'];
    return colors[colorIndex];
}

function showPieceDemo(pieceType) {
    showPiece(pieceType);
}

// Demo AI functionality - can be used to test AI in demo mode
function testAIInDemo() {
    console.log('🤖 Testing AI in demo mode...');
    
    // Force enable AI mode for testing
    window.forceAIMode = true;
    
    // Create a simple test scenario
    const demoGameId = 'demo-ai-test';
    
    // Temporarily set gameId for testing
    window.gameId = demoGameId;
    
    // Show AI thinking
    showAIThinking();
    
    // Test the client-side AI
    setTimeout(() => {
        makeClientSideAIMove();
    }, 1000);
}

// Force AI to move (for testing/debugging)
function forceAIMove() {
    console.log('🤖 FORCING AI MOVE...');
    
    // Override all checks
    window.forceAIMode = true;
    
    if (typeof gameId === 'undefined') {
        window.gameId = 'test-game-' + Date.now();
        console.log('🤖 Created test gameId:', window.gameId);
    }
    
    // Show thinking indicator
    showAIThinking();
    
    // Force client-side AI move
    setTimeout(() => {
        makeClientSideAIMove();
    }, 500);
}

// Enhanced isAIGame to include forced mode
function isAIGameEnhanced() {
    if (window.forceAIMode) {
        console.log('✅ AI game detected (forced mode)');
        return true;
    }
    
    return isAIGame();
}

// Add comprehensive AI debug function
function debugAI() {
    console.log('🔍 AI DEBUG INFORMATION:');
    console.log('------------------------');
    console.log('gameId:', typeof gameId !== 'undefined' ? gameId : 'UNDEFINED');
    console.log('userCanMove:', typeof userCanMove !== 'undefined' ? userCanMove : 'UNDEFINED');
    console.log('isAIGame():', isAIGame());
    console.log('isAIGameEnhanced():', isAIGameEnhanced());
    console.log('forceAIMode:', window.forceAIMode || false);
    console.log('URL:', window.location.href);
    console.log('URL params:', new URLSearchParams(window.location.search).toString());
    
    const gameStatus = document.getElementById('gameStatusText');
    console.log('gameStatusText:', gameStatus ? gameStatus.textContent : 'NOT FOUND');
    
    const boardState = getBoardState();
    console.log('Board pieces found:', boardState ? boardState.pieces.length : 'NO BOARD STATE');
    
    if (boardState) {
        console.log('AI pieces (blue):', boardState.pieces.filter(p => p.player === 'blue').length);
        console.log('Human pieces (red):', boardState.pieces.filter(p => p.player === 'red').length);
    }
    
    // Check all potential AI indicators
    console.log('AI indicators in page:');
    const aiElements = document.querySelectorAll('[class*="ai"], [class*="bot"], [data-ai-game]');
    aiElements.forEach(el => {
        console.log('- Found AI element:', el.tagName, el.className, el.textContent.substring(0, 50));
    });
}

// Add button to test AI (for development/demo purposes)
function addAITestButton() {
    const existingButton = document.getElementById('ai-test-btn');
    if (!existingButton) {
        const button = document.createElement('button');
        button.id = 'ai-test-btn';
        button.textContent = '🤖 Force AI Move';
        button.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            z-index: 1000;
            padding: 10px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        `;
        button.onclick = forceAIMove;
        document.body.appendChild(button);
        
        // Add debug button too
        const debugButton = document.createElement('button');
        debugButton.id = 'ai-debug-btn';
        debugButton.textContent = '🔍 Debug AI';
        debugButton.style.cssText = `
            position: fixed;
            top: 60px;
            right: 10px;
            z-index: 1000;
            padding: 10px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        `;
        debugButton.onclick = debugAI;
        document.body.appendChild(debugButton);
    }
}

console.log('✅ Complete game.js loaded successfully');