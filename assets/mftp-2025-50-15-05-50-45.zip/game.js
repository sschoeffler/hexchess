console.log('🚀 COMPLETE game.js loaded');

// Auth functions
function showAuth(type) {
    document.getElementById('loginForm').style.display = type === 'login' ? 'block' : 'none';
    document.getElementById('registerForm').style.display = type === 'register' ? 'block' : 'none';
}

function login(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'login');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification('Login Failed', data.error, 'error');
        }
    });
}

function register(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'register');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification('Registration Failed', data.error, 'error');
        }
    });
}

function logout() {
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=logout'
    })
    .then(() => location.reload());
}

// Game creation
function createGame(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    formData.append('action', 'create_game');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `?page=game&id=${data.game_id}`;
        } else {
            showNotification('Failed to Create Game', data.error, 'error');
        }
    });
}

// Game joining
function joinGame(gameId) {
    console.log('🎮 Joining game:', gameId);
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=join_game&game_id=${gameId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `?page=game&id=${gameId}`;
        } else {
            showNotification('Failed to Join', data.error, 'error');
        }
    });
}

// Resign game functionality
function resignGame() {
    if (!confirm('⚠️ Are you sure you want to resign?\n\nThis will end the game and count as a loss for you. This action cannot be undone.')) {
        return;
    }
    
    console.log('🏳️ Resigning from game:', gameId);
    
    const resignBtn = document.querySelector('button[onclick="resignGame()"]');
    if (resignBtn) {
        resignBtn.disabled = true;
        resignBtn.textContent = '🏳️ Resigning...';
    }
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=resign&game_id=${gameId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Game Resigned', data.message || 'You have resigned from the game', 'info');
        } else {
            showNotification('Resignation Failed', data.error, 'error');
            if (resignBtn) {
                resignBtn.disabled = false;
                resignBtn.textContent = '🏳️ Resign Game';
            }
        }
    })
    .catch(error => {
        console.error('❌ Resignation error:', error);
        showNotification('Connection Error', 'Unable to resign from game', 'error');
        if (resignBtn) {
            resignBtn.disabled = false;
            resignBtn.textContent = '🏳️ Resign Game';
        }
    });
}

function loadAvailableGames() {
    console.log('🔍 Loading available games...');
    
    fetch(window.location.pathname + '?api=games')
        .then(response => {
            console.log('📡 Response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(games => {
            console.log('✅ Games loaded successfully:', games.length, 'games');
            
            const gameList = document.getElementById('available-games');
            if (!gameList) {
                console.error('❌ gameList element not found');
                return;
            }
            
            if (games.length === 0) {
                gameList.innerHTML = '<p>No games available. Create one!</p>';
                return;
            }
            
            const gameHtml = games.map(game => `
                <div class="game-item">
                    <div class="game-info">
                        <h3>${game.game_name}</h3>
                        <p>${game.current_players}/${game.player_count} players • Created by ${game.creator}</p>
                    </div>
                    <button class="btn" onclick="joinGame('${game.game_id}')">Join</button>
                </div>
            `).join('');
            
            gameList.innerHTML = gameHtml;
            console.log('✅ Game list updated in DOM');
        })
        .catch(error => {
            console.error('❌ Error loading games:', error);
            const gameList = document.getElementById('available-games');
            if (gameList) {
                gameList.innerHTML = '<p>Error loading games. Check console.</p>';
            }
        });
}

// Load user's active games
function loadMyGames() {
    console.log('🎯 Loading my active games...');
    
    fetch(window.location.pathname + '?api=my-games')
        .then(response => {
            console.log('📡 My games response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error('❌ Error from server:', data.error);
                const gameList = document.getElementById('my-games');
                if (gameList) {
                    gameList.innerHTML = '<p>Error: ' + data.error + '</p>';
                }
                return;
            }
            
            const games = data;
            console.log('✅ My games loaded successfully:', games.length, 'games');
            
            const gameList = document.getElementById('my-games');
            if (!gameList) {
                console.error('❌ my-games element not found');
                return;
            }
            
            if (games.length === 0) {
                gameList.innerHTML = '<p>No active games. Join or create one!</p>';
                return;
            }
            
            const gameHtml = games.map(game => {
                let statusText = '';
                let buttonText = '';
                let buttonClass = 'btn';
                
                if (game.status === 'waiting') {
                    statusText = `Waiting for ${game.player_count - game.current_players} more player(s)`;
                    buttonText = 'Enter Waiting Room';
                } else if (game.status === 'active') {
                    statusText = game.is_your_turn ? 'Your turn!' : 'Waiting for other player';
                    buttonText = 'Resume Game';
                    buttonClass = game.is_your_turn ? 'btn' : 'btn btn-secondary';
                } else if (game.status === 'finished') {
                    statusText = game.winner_name ? `Won by ${game.winner_name}` : 'Game ended';
                    buttonText = 'View Game';
                    buttonClass = 'btn btn-secondary';
                }
                
                return `
                    <div class="game-item ${game.is_your_turn ? 'your-turn' : ''}">
                        <div class="game-info">
                            <h3>${game.game_name}</h3>
                            <p>${statusText}</p>
                            <small>${game.current_players}/${game.player_count} players • ${game.status}</small>
                        </div>
                        <button class="${buttonClass}" onclick="resumeGame('${game.game_id}')">${buttonText}</button>
                    </div>
                `;
            }).join('');
            
            gameList.innerHTML = gameHtml;
            console.log('✅ My games list updated in DOM');
        })
        .catch(error => {
            console.error('❌ Error loading my games:', error);
            const gameList = document.getElementById('my-games');
            if (gameList) {
                gameList.innerHTML = '<p>Error loading your games. Try refreshing.</p>';
            }
        });
}

// Resume/enter a game the user is already in
function resumeGame(gameId) {
    console.log('🎮 Resuming game:', gameId);
    window.location.href = `?page=game&id=${gameId}`;
}

// Handle game mode changes
function updateGameModeOptions() {
    const gameMode = document.getElementById('game_mode');
    const playersGroup = document.getElementById('players-group');
    const aiDifficultyGroup = document.getElementById('ai-difficulty-group');
    
    if (!gameMode || !playersGroup || !aiDifficultyGroup) {
        return; // Elements don't exist yet
    }
    
    console.log('🎮 Game mode changed to:', gameMode.value);
    
    if (gameMode.value === 'ai') {
        playersGroup.style.display = 'none';
        aiDifficultyGroup.style.display = 'block';
        
        // Set AI games to 2-player by default
        const playerCount = document.getElementById('player_count');
        if (playerCount) {
            playerCount.value = '2';
        }
    } else {
        playersGroup.style.display = 'block';
        aiDifficultyGroup.style.display = 'none';
    }
    
    updateDefaultGameName();
}

function updateDefaultGameName() {
    const gameNameInput = document.getElementById('game_name');
    const playerCount = document.getElementById('player_count');
    const boardSize = document.getElementById('board_size');
    const gameMode = document.getElementById('game_mode');
    const aiDifficulty = document.getElementById('ai_difficulty');
    
    if (!gameNameInput || !boardSize) return;
    
    const currentValue = gameNameInput.value;
    const isDefaultPattern = /^(2|3)-Player (Small|Medium|Large|Jumbo) Game$/.test(currentValue) ||
                           /^vs AI \((Easy|Medium|Hard)\) (Small|Medium|Large|Jumbo) Game$/.test(currentValue);
    
    if (isDefaultPattern || currentValue === '') {
        const sizeNames = {
            '5': 'Small', '6': 'Medium', '7': 'Large', '8': 'Jumbo'
        };
        
        let defaultName;
        if (gameMode && gameMode.value === 'ai' && aiDifficulty) {
            const difficultyNames = {
                'easy': 'Easy', 'medium': 'Medium', 'hard': 'Hard'
            };
            defaultName = `vs AI (${difficultyNames[aiDifficulty.value]}) ${sizeNames[boardSize.value]} Game`;
        } else if (playerCount) {
            defaultName = `${playerCount.value}-Player ${sizeNames[boardSize.value]} Game`;
        }
        
        if (defaultName) {
            gameNameInput.value = defaultName;
        }
    }
}

function resetToDefaultName() {
    const playerCount = document.getElementById('player_count').value;
    const boardSize = document.getElementById('board_size').value;
    const gameNameInput = document.getElementById('game_name');
    
    const sizeNames = {
        '5': 'Small',
        '6': 'Medium', 
        '7': 'Large',
        '8': 'Jumbo'
    };
    
    const defaultName = `${playerCount}-Player ${sizeNames[boardSize]} Game`;
    gameNameInput.value = defaultName;
    
    showNotification('✅ Name Reset', 'Game name reset to default', 'success');
}

function showNotification(title, message, type = 'error') {
    console.log(`📢 Notification: ${title} - ${message}`);
    
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-title">${title}</div>
        <div class="notification-message">${message}</div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('show'), 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Game-specific JavaScript
function selectHex(q, r) {
    console.log('🎯 selectHex called:', q, r, 'gameId:', typeof gameId !== 'undefined' ? gameId : 'UNDEFINED');
    
    if (typeof userCanMove !== 'undefined' && !userCanMove) {
        showNotification('Not Your Turn', 'Wait for your turn to move', 'warning');
        return;
    }
    
    const cell = document.querySelector(`[data-q="${q}"][data-r="${r}"]`);
    
    if (selectedHex && selectedHex.q === q && selectedHex.r === r) {
        clearSelection();
        return;
    }
    
    if (selectedHex && cell.classList.contains('valid-move')) {
        makeMove(selectedHex.q, selectedHex.r, q, r);
        return;
    }
    
    // Check if there's actually a piece at this position
    const piece = cell.querySelector('.piece');
    if (!piece) {
        clearSelection();
        return; // No piece here, don't show any moves
    }
    
    clearSelection();
    selectedHex = {q: q, r: r};
    cell.classList.add('selected');
    
    if (typeof gameId !== 'undefined') {
        getValidMoves(q, r);
    } else {
        // For demo mode, highlight some example moves
        highlightValidMoves(q, r);
    }
}

function clearSelection() {
    document.querySelectorAll('.hex-cell').forEach(cell => {
        cell.classList.remove('selected', 'valid-move');
    });
    selectedHex = null;
}

function clearCheckHighlights() {
    document.querySelectorAll('.hex-cell').forEach(cell => {
        cell.classList.remove('king-in-check');
    });
}

function highlightValidMoves(q, r) {
    const directions = [
        [1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1],
        [2, -1], [1, -2], [-1, -1], [-2, 1], [-1, 2], [1, 1]
    ];
    
    directions.forEach(([dq, dr]) => {
        const newQ = q + dq;
        const newR = r + dr;
        const targetCell = document.querySelector(`[data-q="${newQ}"][data-r="${newR}"]`);
        if (targetCell) {
            targetCell.classList.add('valid-move');
        }
    });
}

function getValidMoves(q, r) {
    console.log('🎯 Getting valid moves for:', q, r, 'gameId:', gameId);
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=getValidMoves&game_id=${gameId}&fromQ=${q}&fromR=${r}`
    })
    .then(response => response.json())
    .then(data => {
        console.log('📡 Server response:', data);
        
        if (data.success && data.validMoves && data.validMoves.length > 0) {
            console.log('✅ Found', data.validMoves.length, 'valid moves');
            data.validMoves.forEach(move => {
                const targetCell = document.querySelector(`[data-q="${move.q}"][data-r="${move.r}"]`);
                if (targetCell) {
                    targetCell.classList.add('valid-move');
                }
            });
        } else {
            console.log('❌ No valid moves or error:', data);
            clearSelection();
        }
    })
    .catch(error => {
        console.error('❌ Fetch error:', error);
        clearSelection();
    });
}

function makeMove(fromQ, fromR, toQ, toR) {
    console.log('🎯 Making move:', fromQ, fromR, '→', toQ, toR);
    
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=move&game_id=${gameId}&fromQ=${fromQ}&fromR=${fromR}&toQ=${toQ}&toR=${toR}`
    })
    .then(response => response.json())
    .then(data => {
        console.log('📡 Move response:', data);
        
        if (data.success) {
            showNotification('✅ Move Made', 'Your move was successful', 'success');
            
            // Force page reload to show updated board
            setTimeout(() => {
                location.reload();
            }, 1000);
            
        } else {
            if (data.errorType === 'exposes-king') {
                showNotification('⚠️ King in Danger!', 'That move would expose your king to check', 'warning');
            } else if (data.errorType === 'wrong-player') {
                showNotification('❌ Wrong Piece', 'You can only move your own pieces', 'error');
            } else if (data.errorType === 'no-piece') {
                showNotification('❌ No Piece', 'No piece at selected position', 'error');
            } else {
                showNotification('❌ Invalid Move', data.error || 'Move not allowed', 'error');
            }
        }
        clearSelection();
    })
    .catch(error => {
        console.error('❌ Move error:', error);
        showNotification('❌ Connection Error', 'Unable to make move', 'error');
        clearSelection();
    });
}

// Check if it's the AI's turn and trigger AI move
function checkForAIMove() {
    // Only check for AI moves if we have gameId defined (not in demo mode)
    if (typeof gameId === 'undefined') {
        return;
    }
    
    console.log('🤖 Checking for AI move...');
    
    // Show AI thinking indicator
    showAIThinking();
    
    // Add a small delay to make the AI move feel more natural
    setTimeout(() => {
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=ai_move&game_id=${gameId}`
        })
        .then(response => response.json())
        .then(data => {
            hideAIThinking();
            
            if (data.success) {
                console.log('🤖 AI made move successfully');
                
                // Show AI move notification
                if (data.aiName) {
                    showNotification('🤖 AI Move', `${data.aiName} has made their move`, 'info');
                }
                
                // Force page reload to show AI move
                setTimeout(() => {
                    location.reload();
                }, 1500);
                
            } else {
                // If error is "Not AI turn" or "Not an AI game", that's fine - just ignore
                if (data.error && !data.error.includes('Not AI') && !data.error.includes('Not an AI game')) {
                    console.error('🤖 AI move error:', data.error);
                }
            }
        })
        .catch(error => {
            hideAIThinking();
            console.error('🤖 AI move fetch error:', error);
        });
    }, 1500); // 1.5 second delay
}

// Show AI thinking indicator
function showAIThinking() {
    const gameStatus = document.getElementById('gameStatusText');
    if (gameStatus && !document.querySelector('.ai-thinking')) {
        const thinkingDiv = document.createElement('div');
        thinkingDiv.className = 'ai-thinking';
        thinkingDiv.innerHTML = '🤖 AI is thinking...';
        gameStatus.appendChild(thinkingDiv);
    }
}

// Hide AI thinking indicator
function hideAIThinking() {
    const thinkingDiv = document.querySelector('.ai-thinking');
    if (thinkingDiv) {
        thinkingDiv.remove();
    }
}

function highlightKingsInCheck(kingsInCheck) {
    clearCheckHighlights();
    kingsInCheck.forEach(king => {
        const kingCell = document.querySelector(`[data-q="${king.q}"][data-r="${king.r}"]`);
        if (kingCell) {
            kingCell.classList.add('king-in-check');
        }
    });
}

function updateGameState(gameState) {
    if (gameState.gameStatus.gameOver) {
        showNotification('🏁 Game Over', 'Game has ended!', 'success');
        if (typeof userCanMove !== 'undefined') {
            userCanMove = false;
        }
        
        // Hide the resign button since game is over
        const resignBtn = document.querySelector('button[onclick="resignGame()"]');
        if (resignBtn) {
            resignBtn.style.display = 'none';
        }
    }
}

// Main game functions for demo mode
function newGame() {
    if (typeof gameId === 'undefined') {
        // Demo mode
        location.reload();
    } else {
        // Real game mode
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=newgame'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

function showMovementDemo() {
    const modal = document.getElementById('demoModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeDemoModal() {
    document.getElementById('demoModal').style.display = 'none';
    const demoBoard = document.getElementById('demoBoard');
    if (demoBoard) {
        demoBoard.style.display = 'none';
        demoBoard.innerHTML = '';
    }
    document.querySelectorAll('.demo-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('demoInfo').innerHTML = '<p>Select a piece above to see its movement pattern demonstrated on the full game board.</p>';
}

// DEMO FUNCTIONS
function showPiece(pieceType) {
    console.log('🎭 showPiece called for:', pieceType);
    
    if (window.demoProcessing) {
        return;
    }
    
    window.demoProcessing = true;
    
    try {
        // Update UI
        document.querySelectorAll('.piece-nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const navButton = document.getElementById(`nav-${pieceType}`);
        if (navButton) {
            navButton.classList.add('active');
        }
        
        document.querySelectorAll('.piece-desc').forEach(desc => {
            desc.classList.remove('active');
        });
        
        const descElement = document.getElementById(`desc-${pieceType}`);
        if (descElement) {
            descElement.classList.add('active');
        }
        
        // Clear highlights
        document.querySelectorAll('.hex-cell').forEach(cell => {
            cell.classList.remove('selected', 'valid-move', 'capture-square');
        });
        
        // Update piece and show pattern
        updateBoardPiece(pieceType);
        showMovementPattern(pieceType);
        
        console.log('✅ Demo complete for:', pieceType);
        
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        setTimeout(() => {
            window.demoProcessing = false;
        }, 100);
    }
}

function updateBoardPiece(pieceType) {
    const pieceIcons = {
        'king': '♚', 'queen': '♛', 'rook': '♜',
        'bishop': '♝', 'knight': '♞', 'pawn': '♟'
    };
    
    let demoQ, demoR;
    switch (pieceType) {
        case 'pawn':
            demoQ = -5; demoR = 0;
            break;
        default:
            demoQ = 0; demoR = 0;
    }
    
    // Clear all pieces
    document.querySelectorAll('.hex-content').forEach(content => {
        content.innerHTML = '';
    });
    
    // Place new piece
    const pieceCell = document.querySelector(`[data-q="${demoQ}"][data-r="${demoR}"]`);
    if (pieceCell) {
        const pieceContent = pieceCell.querySelector('.hex-content');
        if (pieceContent) {
            pieceContent.innerHTML = `<span class='piece red-piece'>${pieceIcons[pieceType]}</span>`;
        }
    }
}

function showMovementPattern(pieceType) {
    let demoQ, demoR;
    switch (pieceType) {
        case 'pawn':
            demoQ = -5; demoR = 0;
            break;
        default:
            demoQ = 0; demoR = 0;
    }
    
    // Highlight piece position
    const pieceCell = document.querySelector(`[data-q="${demoQ}"][data-r="${demoR}"]`);
    if (pieceCell) {
        pieceCell.classList.add('selected');
    }
    
    // Get moves and highlight them
    const validMoves = getValidMovesForPiece(pieceType, demoQ, demoR);
    
    console.log(`🎯 ${pieceType} valid moves:`, validMoves.length);
    
    validMoves.forEach(move => {
        const cell = document.querySelector(`[data-q="${move.q}"][data-r="${move.r}"]`);
        if (cell) {
            if (move.type === 'capture') {
                cell.classList.add('capture-square');
            } else {
                cell.classList.add('valid-move');
            }
        }
    });
}

function getValidMovesForPiece(pieceType, fromQ, fromR) {
    const moves = [];
    
    switch (pieceType) {
        case 'pawn':
            moves.push({q: fromQ + 1, r: fromR, type: 'move'});
            moves.push({q: fromQ + 1, r: fromR + 1, type: 'capture'});
            moves.push({q: fromQ + 2, r: fromR - 1, type: 'capture'});
            break;
            
        case 'bishop':
            const bishopDirections = [
                [1, 1], [-1, -1],
                [2, -1], [-2, 1],
                [1, -2], [-1, 2]
            ];
            
            bishopDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'queen':
            const queenDirections = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1],
                [1, 1], [-1, -1], [2, -1], [-2, 1], [1, -2], [-1, 2]
            ];
            
            queenDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'rook':
            const rookDirections = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1]
            ];
            
            rookDirections.forEach(([dq, dr]) => {
                for (let step = 1; step <= 8; step++) {
                    const newQ = fromQ + dq * step;
                    const newR = fromR + dr * step;
                    
                    if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                        moves.push({q: newQ, r: newR, type: 'move'});
                    } else {
                        break;
                    }
                }
            });
            break;
            
        case 'knight':
            const knightMoves = [
                [2, 1], [3, -1], [1, 2], [-1, 3],
                [-2, 3], [-3, 2], [-3, 1], [-2, -1],
                [-1, -2], [1, -3], [2, -3], [3, -2]
            ];
            
            knightMoves.forEach(([dq, dr]) => {
                const newQ = fromQ + dq;
                const newR = fromR + dr;
                
                if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                    moves.push({q: newQ, r: newR, type: 'move'});
                }
            });
            break;
            
        case 'king':
            const kingMoves = [
                [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1],
                [1, 1], [-1, -1], [2, -1], [-2, 1], [1, -2], [-1, 2]
            ];
            
            kingMoves.forEach(([dq, dr]) => {
                const newQ = fromQ + dq;
                const newR = fromR + dr;
                
                if (Math.abs(newQ) <= 8 && Math.abs(newR) <= 8 && Math.abs(newQ + newR) <= 8) {
                    moves.push({q: newQ, r: newR, type: 'move'});
                }
            });
            break;
    }
    
    return moves;
}

// Auto-load demo
function initializeDemoPage() {
    console.log('🚀 Initializing demo page with king moves');
    
    setTimeout(() => {
        showPiece('king');
    }, 500);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Game.js initialized');
    
    // Force hexagon shapes on all cells
    //document.querySelectorAll('.hex-cell').forEach(cell => {
      //  cell.style.clipPath = 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)';
    //});
    
    // Demo page auto-init
    if (window.location.search.includes('page=demo')) {
        console.log('📚 Demo page detected, will auto-show king moves');
        initializeDemoPage();
    }
    
    const modal = document.getElementById('demoModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeDemoModal();
            }
        });
    }
    
    // Load available games if on lobby page
    if (document.getElementById('available-games')) {
        loadAvailableGames();
    }
    
    // Load user's games if on lobby page
    if (document.getElementById('my-games')) {
        loadMyGames();
    }

// Replace the hover effects section in your game.js with this:

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const modal = document.getElementById('demoModal');
        const demoBoard = document.getElementById('demoBoard');
        if (modal && modal.style.display === 'flex') {
            if (demoBoard && demoBoard.style.display === 'block') {
                demoBoard.style.display = 'none';
                demoBoard.innerHTML = '';
                document.querySelectorAll('.demo-btn').forEach(btn => btn.classList.remove('active'));
                document.getElementById('demoInfo').innerHTML = '<p>Select a piece above to see its movement pattern demonstrated on the full game board.</p>';
            } else {
                closeDemoModal();
            }
        } else {
            clearSelection();
        }
    }
});


// Helper functions
function isValidHex(q, r) {
    const BOARD_SIZE = 8;
    return Math.abs(q) <= BOARD_SIZE && 
           Math.abs(r) <= BOARD_SIZE && 
           Math.abs(q + r) <= BOARD_SIZE;
}

function getCellColor(q, r) {
    const colorIndex = ((q - r) % 3 + 3) % 3;
    const colors = ['pastel-red', 'pastel-green', 'pastel-blue'];
    return colors[colorIndex];
}

function showPieceDemo(pieceType) {
    showPiece(pieceType);
}

});

console.log('✅ Complete game.js loaded successfully');