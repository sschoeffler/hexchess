<?php
function renderBoard($game, $gameId, $canMove) {
$boardSize = $game->getBoardSize();
$html = '<div class="hex-board">';
for ($r = -$boardSize; $r <= $boardSize; $r++) {
$html .= '<div class="hex-row">';
$qMin = max(-$boardSize, -$r - $boardSize);
$qMax = min($boardSize, -$r + $boardSize);
for ($q = $qMin; $q <= $qMax; $q++) {
$piece = $game->getPiece($q, $r);
$colorClass = getCellColor($q, $r);
$html .= '<div class="hex-cell ' . $colorClass . '" data-q="' . $q . '" data-r="' . $r . '" onclick="selectHex(' . $q . ', ' . $r . ')">';
$html .= '<div class="hex-content">';
if ($piece) {
$pieceClass = getPieceClass($piece->player);
$pieceSymbol = getPieceSymbol($piece->type);
$html .= '<span class="piece ' . $pieceClass . '">' . $pieceSymbol . '</span>';
 }
$html .= '</div></div>';
 }
$html .= '</div>';
 }
$html .= '</div>';
return $html;
}
function renderDemoBoard($game, $pieceType) {
$boardSize = $game->getBoardSize();
$html = '<div class="hex-board">';
for ($r = -$boardSize; $r <= $boardSize; $r++) {
$html .= '<div class="hex-row">';
$qMin = max(-$boardSize, -$r - $boardSize);
$qMax = min($boardSize, -$r + $boardSize);
for ($q = $qMin; $q <= $qMax; $q++) {
$piece = $game->getPiece($q, $r);
$colorClass = getCellColor($q, $r);
$html .= '<div class="hex-cell ' . $colorClass . '" data-q="' . $q . '" data-r="' . $r . '" onclick="selectHex(' . $q . ', ' . $r . ')">';
$html .= '<div class="hex-content">';
if ($piece) {
$pieceClass = getPieceClass($piece->player);
$pieceSymbol = getPieceSymbol($piece->type);
$html .= '<span class="piece ' . $pieceClass . '">' . $pieceSymbol . '</span>';
 }
$html .= '</div></div>';
 }
$html .= '</div>';
 }
$html .= '</div>';
return $html;
}
function createDemoBoard() {
// Create a demo game with a single piece for demonstration
$game = new HexChess('demo', 2, 8);
// Clear the board
$game->clearBoard();
// Place a single red king in the center for demo
$game->placeDemoPiece(0, 0, new Piece('king', 0));
return $game;
}
function getCellColor($q, $r) {
$colorIndex = (($q - $r) % 3 + 3) % 3;
$colors = ['pastel-red', 'pastel-green', 'pastel-blue'];
return $colors[$colorIndex];
}
function getPieceClass($player) {
$classes = ['red-piece', 'blue-piece', 'green-piece'];
return $classes[$player] ?? 'red-piece';
}
function getPieceSymbol($type) {
$symbols = [
'king' => '♚',
'queen' => '♛',
'rook' => '♜',
'bishop' => '♝',
'knight' => '♞',
'pawn' => '♟'
 ];
return $symbols[$type] ?? '?';
}